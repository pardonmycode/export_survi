# Monster Detektiv

## Decision Tree
### Instruktion
- Kinder sollen Monster von freundlich und gefährlich unterscheiden mit Hilfe eines EnscheidungsBaum
- Dabei sollen sie selber diesen EnstscheidungsBaum konstruieren und validieren 
- So wenig wie moeglich erklaeren, die Kinder sollen eigentstaendig suchen und nuzten

### Goal 
- Kinder lernen EntscheidungsBäume kennen
- Unterscheiden von TrainingsDaten und TestDaten

### Aufwand
- 10-15 Min.




## Random Forest
### Instruktion
- Kinder sollen Monster von freundlich und gefährlich unterscheiden mit Hilfe eines Random Forest
- Prinipell sind es einfach mehrere EntscheidungsBäume 
- Dabei sollen sie selber diesen EnstscheidungsBaum konstruieren und validieren 

### Goal 
- Kinder lernen EntscheidungsBäume kennen 
- Dadruch das die Monster mehrere Merkmale besitzen 
- Es wird mit der Mehrheit der EntscheidungsBäume entschieden

### Aufwand
- 10-15 Min.

## TODO  
- Kahoot Fragen dazu erstellen
