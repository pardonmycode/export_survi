from __future__ import annotations



import sys
import math
import random

from dataclasses import dataclass

from typing import Dict, List, Optional, Sequence, Tuple



import pygame





WIDTH, HEIGHT, FPS = 1180, 780, 60
WINDOW_WIDTH, WINDOW_HEIGHT = 1440, 950
TREE_WIDTH, TREE_HEIGHT = WINDOW_WIDTH, WINDOW_HEIGHT



BG = (244, 247, 251)

PANEL = (255, 255, 255)

PANEL_ALT = (235, 241, 248)



TEXT = (30, 37, 48)

MUTED = (96, 108, 124)

BORDER = (190, 200, 214)



ACCENT = (60, 105, 210)

ACCENT_LIGHT = (220, 231, 255)



GOOD = (61, 154, 88)

GOOD_LIGHT = (224, 244, 230)



BAD = (202, 74, 74)

BAD_LIGHT = (251, 227, 227)



WHITE = (255, 255, 255)

BLACK = (20, 24, 29)

YELLOW = (244, 190, 66)



COLORS = {

    "grün": (89, 177, 95),

    "blau": (78, 132, 208),

    "rot": (211, 91, 91),

}





# ------------------------------------------------------------

# MONSTER

# ------------------------------------------------------------



@dataclass(frozen=True)

class Monster:

    name: str

    color: str

    horns: bool

    wings: bool

    big: bool

    antennae: bool

    label: str





def make_monster(

    name: str,

    color: str,

    horns: bool,

    wings: bool,

    big: bool,

) -> Monster:



    # Antennen sind ein echtes, sichtbares Zusatzmerkmal.
    # Es wird stabil aus dem Namen abgeleitet, damit alle Monster feste Werte haben.
    # Die geheime Klassenregel benutzt dieses Merkmal absichtlich nicht.
    style = sum((i + 1) * ord(ch) for i, ch in enumerate(name))
    antennae = style % 2 == 0

    # Geheime Regel (Challenge):
    # Ein einzelnes Merkmal reicht nicht mehr. Gefährlich ist ein Monster, wenn
    # mehrere Eigenschaften zusammenpassen. Dadurch braucht der Baum tiefere
    # und sinnvollere Entscheidungen.
    dangerous = (
        (horns and wings)
        or (horns and big)
        or (wings and color == "rot")
        or (color == "grün" and big and not horns)
    )
    label = "gefährlich" if dangerous else "freundlich"



    return Monster(

        name,

        color,

        horns,

        wings,

        big,

        antennae,

        label,

    )





TRAINING = [

    make_monster("Momo", "grün", False, False, False),

    make_monster("Rex", "rot", True, False, True),

    make_monster("Luna", "blau", False, True, False),

    make_monster("Bobo", "grün", False, False, True),

    make_monster("Zack", "rot", True, True, False),

    make_monster("Mila", "blau", False, False, False),

    make_monster("Kroko", "grün", True, False, False),

    make_monster("Fips", "rot", False, True, True),

    make_monster("Nala", "blau", False, False, True),

    make_monster("Drago", "grün", True, True, True),

    make_monster("Pico", "rot", False, False, False),

    make_monster("Wuschel", "blau", True, False, False),

    make_monster("Gizmo", "grün", False, True, False),

    make_monster("Rocky", "rot", True, False, False),

    make_monster("Flocke", "blau", False, False, True),

    make_monster("Knuffel", "grün", False, False, False),

    make_monster("Blitz", "rot", True, True, True),

    make_monster("Nemo", "blau", False, True, True),

    make_monster("Poldi", "grün", True, False, True),

    make_monster("Tapsi", "rot", False, False, False),

    make_monster("Wolke", "blau", True, True, False),

    make_monster("Krümel", "grün", False, True, True),

    make_monster("Rocco", "rot", False, False, True),

    make_monster("Susi", "blau", True, False, False),

]





TEST_DATA = [

    make_monster("Trixi", "grün", False, True, True),

    make_monster("Keks", "rot", False, False, True),

    make_monster("Nova", "blau", True, False, True),

    make_monster("Plopp", "grün", False, False, False),

    make_monster("Rudi", "rot", True, True, True),

    make_monster("Sky", "blau", False, True, False),

    make_monster("Pepper", "grün", True, False, False),

    make_monster("Mini", "rot", False, False, False),

    make_monster("Zora", "blau", False, False, True),

    make_monster("Bruno", "grün", True, True, False),

    make_monster("Kiki", "rot", False, True, False),

    make_monster("Olli", "blau", False, False, False),

    make_monster("Frida", "grün", True, False, True),

    make_monster("Balu", "rot", False, False, True),

    make_monster("Loki", "blau", True, True, True),

    make_monster("Pippa", "grün", False, False, False),

]





FEATURE_LABELS: Dict[str, str] = {

    "horns": "Hat Hörner?",

    "wings": "Hat Flügel?",

    "big": "Ist es groß?",

    "green": "Ist es grün?",

    "antennae": "Hat es Antennen?",

}



FEATURE_SHORT = {

    "horns": "Hörner",

    "wings": "Flügel",

    "big": "Groß",

    "green": "Grün",

    "antennae": "Antennen",

}



FEATURES = list(FEATURE_LABELS)





def feature_value(monster: Monster, feature: str) -> bool:

    if feature == "horns":

        return monster.horns



    if feature == "wings":

        return monster.wings



    if feature == "big":

        return monster.big



    if feature == "green":

        return monster.color == "grün"

    if feature == "antennae":

        return monster.antennae



    raise ValueError(feature)





# ------------------------------------------------------------

# BUTTON

# ------------------------------------------------------------



@dataclass

class Button:

    rect: pygame.Rect

    text: str

    action: str

    value: Optional[str] = None



    enabled: bool = True

    active: bool = False



    def draw(

        self,

        surface: pygame.Surface,

        font: pygame.font.Font,

        small: pygame.font.Font,

    ) -> None:



        if not self.enabled:

            fill = (229, 233, 239)

            border = (203, 209, 217)

            color = (142, 150, 162)



        elif self.active:

            fill = ACCENT_LIGHT

            border = ACCENT

            color = TEXT



        else:

            fill = PANEL

            border = BORDER

            color = TEXT



        pygame.draw.rect(

            surface,

            fill,

            self.rect,

            border_radius=10,

        )



        pygame.draw.rect(

            surface,

            border,

            self.rect,

            width=2,

            border_radius=10,

        )



        f = small if len(self.text) > 18 else font



        img = f.render(

            self.text,

            True,

            color,

        )



        surface.blit(

            img,

            img.get_rect(center=self.rect.center),

        )





# ------------------------------------------------------------

# BAUM-BAUSTEIN FUER DEN RANDOM FOREST

# ------------------------------------------------------------



@dataclass
class TreeNode:
    feature: Optional[str] = None
    yes: Optional["TreeNode"] = None
    no: Optional["TreeNode"] = None
    override: Optional[str] = None

    @property
    def is_leaf(self) -> bool:
        return self.feature is None



class ForestTree:
    def __init__(
        self,
        data: Sequence[Monster],
        root: TreeNode,
    ) -> None:
        self.data = list(data)
        self.root = root
        self._ensure_children(self.root)

    def _ensure_children(self, node: TreeNode) -> None:
        if node.is_leaf:
            node.yes = None
            node.no = None
            return

        if node.yes is None:
            node.yes = TreeNode()
        if node.no is None:
            node.no = TreeNode()

        self._ensure_children(node.yes)
        self._ensure_children(node.no)

    @staticmethod
    def majority(
        items: Sequence[Monster],
        fallback: str = "freundlich",
    ) -> str:
        if not items:
            return fallback

        dangerous = sum(
            m.label == "gefährlich"
            for m in items
        )
        friendly = len(items) - dangerous

        if dangerous > friendly:
            return "gefährlich"
        return "freundlich"

    def node_at(
        self,
        path: Tuple[bool, ...],
    ) -> Optional[TreeNode]:
        node = self.root

        for answer in path:
            if node.is_leaf:
                return None
            node = node.yes if answer else node.no
            if node is None:
                return None

        return node

    def parent_feature(
        self,
        path: Tuple[bool, ...],
    ) -> Optional[str]:
        if not path:
            return None

        parent = self.node_at(path[:-1])
        if parent is None:
            return None
        return parent.feature

    def items_for_path(
        self,
        path: Tuple[bool, ...],
    ) -> List[Monster]:
        items = list(self.data)
        node = self.root

        for answer in path:
            if node.is_leaf or node.feature is None:
                break

            items = [
                m
                for m in items
                if feature_value(m, node.feature) == answer
            ]

            next_node = node.yes if answer else node.no
            if next_node is None:
                break
            node = next_node

        return items

    def fallback_label(
        self,
        path: Tuple[bool, ...],
    ) -> str:
        for length in range(len(path), -1, -1):
            items = self.items_for_path(path[:length])
            if items:
                return self.majority(items)
        return "freundlich"

    def leaf_label(
        self,
        path: Tuple[bool, ...],
    ) -> str:
        node = self.node_at(path)
        if node is not None and node.is_leaf and node.override is not None:
            return node.override

        items = self.items_for_path(path)
        return self.majority(items, self.fallback_label(path[:-1]))

    def leaf_counts(
        self,
        path: Tuple[bool, ...],
    ) -> Tuple[int, int]:
        items = self.items_for_path(path)
        dangerous = sum(
            m.label == "gefährlich"
            for m in items
        )
        friendly = len(items) - dangerous
        return dangerous, friendly

    def cycle_leaf(
        self,
        path: Tuple[bool, ...],
    ) -> None:
        node = self.node_at(path)
        if node is None or not node.is_leaf:
            return

        if node.override is None:
            node.override = "freundlich"
        elif node.override == "freundlich":
            node.override = "gefährlich"
        else:
            node.override = None

    def split_leaf(
        self,
        path: Tuple[bool, ...],
        feature: str,
    ) -> bool:
        node = self.node_at(path)
        if node is None or not node.is_leaf:
            return False

        node.feature = feature
        node.override = None
        node.yes = TreeNode()
        node.no = TreeNode()
        return True

    def delete_leaf(
        self,
        path: Tuple[bool, ...],
    ) -> bool:
        # Das Wurzelblatt selbst kann nicht geloescht werden.
        # Beim Loeschen eines normalen Blatts wird der Split direkt
        # darueber zurueckgenommen und der Elternknoten wieder ein Blatt.
        if not path:
            return False

        node = self.node_at(path)
        if node is None or not node.is_leaf:
            return False

        parent = self.node_at(path[:-1])
        if parent is None or parent.is_leaf:
            return False

        parent.feature = None
        parent.override = None
        parent.yes = None
        parent.no = None
        return True

    def iter_nodes(self):
        def walk(
            node: TreeNode,
            path: Tuple[bool, ...],
            depth: int,
        ):
            yield path, node, depth
            if not node.is_leaf:
                if node.yes is not None:
                    yield from walk(node.yes, path + (True,), depth + 1)
                if node.no is not None:
                    yield from walk(node.no, path + (False,), depth + 1)

        yield from walk(self.root, (), 0)

    def leaf_count(self) -> int:
        return sum(
            1
            for _path, node, _depth in self.iter_nodes()
            if node.is_leaf
        )

    def predict(
        self,
        monster: Monster,
    ) -> Tuple[str, List[Tuple[str, bool]]]:
        node = self.root
        path_key: Tuple[bool, ...] = ()
        path: List[Tuple[str, bool]] = []

        while not node.is_leaf:
            assert node.feature is not None
            answer = feature_value(monster, node.feature)
            path.append((node.feature, answer))
            path_key = path_key + (answer,)

            next_node = node.yes if answer else node.no
            if next_node is None:
                break
            node = next_node

        return self.leaf_label(path_key), path

    def accuracy(
        self,
        items: Sequence[Monster],
    ) -> float:
        if not items:
            return 0.0

        correct = sum(
            self.predict(m)[0] == m.label
            for m in items
        )
        return correct / len(items)



@dataclass
class ForestMember:
    sample: List[Monster]
    tree: ForestTree
    scroll_x: int = 0
    scroll_y: int = 0


# ------------------------------------------------------------

# SPIEL

# ------------------------------------------------------------



class Game:

    def __init__(self) -> None:

        pygame.init()



        pygame.display.set_caption(

            "Monster-Detektiv – Random Forest"

        )



        self.display = pygame.display.set_mode(

            (WINDOW_WIDTH, WINDOW_HEIGHT),

            pygame.DOUBLEBUF,

        )

        # Training und Test bleiben unskaliert bei 1180 x 780.
        # Beim Bauen des Waldes nutzt die Canvas dagegen das volle Fenster.
        self.canvas_offset = (
            (WINDOW_WIDTH - WIDTH) // 2,
            (WINDOW_HEIGHT - HEIGHT) // 2,
        )

        self.canvas = pygame.Surface(
            (WIDTH, HEIGHT)
        ).convert()



        self.clock = pygame.time.Clock()



        self.tiny = pygame.font.SysFont(

            "arial",

            13,

        )



        self.small = pygame.font.SysFont(

            "arial",

            16,

        )



        self.font = pygame.font.SysFont(

            "arial",

            19,

        )



        self.bold = pygame.font.SysFont(

            "arial",

            19,

            bold=True,

        )



        self.big = pygame.font.SysFont(

            "arial",

            28,

            bold=True,

        )



        self.huge = pygame.font.SysFont(

            "arial",

            40,

            bold=True,

        )



        # ----------------------------------------------------

        # SPIELSTATUS

        # ----------------------------------------------------



        self.phase = 1



        self.selected_training = 0

        # ----------------------------------------------------
        # RANDOM FOREST: mehrere vom Spieler gebaute Baeume
        # ----------------------------------------------------

        # Mindestens zwei Baeume. Der Spieler kann die Anzahl in Phase 2
        # jederzeit erhoehen oder (bis mindestens 2) verringern.
        self.num_trees = 3

        # Diese Zahl ist zugleich das maximale Blatt-Limit pro Baum.
        self.max_features = 2

        self.active_tree_index = 0
        self.forest_members: List[ForestMember] = []
        self._create_initial_forest()

        # Alias auf den gerade bearbeiteten Baum. Dadurch koennen Zeichnen,
        # Scrollen und Blatt-Menue genau wie beim Einzelbaum funktionieren.
        self.tree = self.forest_members[0].tree
        self.tree_root = self.tree.root

        # Anklickbare Bereiche der sichtbaren Blaetter
        self.leaf_hitboxes: Dict[
            Tuple[bool, ...],
            pygame.Rect,
        ] = {}

        # Kontextmenue fuer Rechtsklick auf ein Blatt
        self.context_leaf_path: Optional[Tuple[bool, ...]] = None
        self.context_menu_pos: Optional[Tuple[int, int]] = None

        # Scrollposition des gerade sichtbaren Baums
        self.tree_scroll_x = 0
        self.tree_scroll_y = 0
        self.tree_scroll_limits = (0, 0)
        self.tree_view_rect = pygame.Rect(0, 0, 0, 0)

        # Sichtbare Scrollbalken fuer grosse Baeume.
        self.tree_h_scroll_track = pygame.Rect(0, 0, 0, 0)
        self.tree_v_scroll_track = pygame.Rect(0, 0, 0, 0)
        self.tree_h_scroll_thumb = pygame.Rect(0, 0, 0, 0)
        self.tree_v_scroll_thumb = pygame.Rect(0, 0, 0, 0)
        self.tree_scroll_drag: Optional[str] = None
        self.tree_scroll_drag_offset = 0

        # Test

        self.test_index = 0



        self.prediction: Optional[str] = None

        self.vote_dangerous = 0
        self.vote_friendly = 0
        self.individual_votes: List[str] = []
        self.individual_paths: List[List[Tuple[str, bool]]] = []

        self.score = 0



        self.test_finished = False



        self.answered: set[int] = set()



        self.buttons: List[Button] = []



    # --------------------------------------------------------

    # TEXT

    # --------------------------------------------------------



    def text(

        self,

        font: pygame.font.Font,

        txt: str,

        pos: Tuple[int, int],

        color=TEXT,

    ) -> None:



        self.canvas.blit(

            font.render(

                txt,

                True,

                color,

            ),

            pos,

        )



    def centered(

        self,

        font: pygame.font.Font,

        txt: str,

        center: Tuple[int, int],

        color=TEXT,

    ) -> None:



        img = font.render(

            txt,

            True,

            color,

        )



        self.canvas.blit(

            img,

            img.get_rect(

                center=center,

            ),

        )



    def wrap(

        self,

        font: pygame.font.Font,

        txt: str,

        rect: pygame.Rect,

        color=MUTED,

    ) -> None:



        words = txt.split()



        lines: List[str] = []



        current = ""



        for word in words:

            test = (

                word

                if not current

                else current + " " + word

            )



            if font.size(test)[0] <= rect.width:

                current = test



            else:

                if current:

                    lines.append(current)



                current = word



        if current:

            lines.append(current)



        y = rect.top



        for line in lines:

            self.text(

                font,

                line,

                (rect.left, y),

                color,

            )



            y += font.get_height() + 4



    # --------------------------------------------------------

    # MONSTER ZEICHNEN

    # --------------------------------------------------------



    def draw_monster(

        self,

        monster: Monster,

        center: Tuple[int, int],

        scale: float = 1.0,

    ) -> None:



        cx, cy = center



        # Alle dekorativen Varianten werden nur aus dem Namen abgeleitet.

        # Dadurch verrät die Optik niemals die Klasse des Monsters.

        style = sum(

            (i + 1) * ord(ch)

            for i, ch in enumerate(monster.name)

        )



        ear_style = style % 4

        eye_style = (style // 3) % 4

        spot_style = (style // 5) % 4

        tail_style = (style // 7) % 4

        antenna_style = (1 + (style // 11) % 2) if monster.antennae else 0

        tooth_style = (style // 13) % 4

        accessory_style = (style // 17) % 6

        mouth_style = (style // 19) % 3



        body_w = int(

            (86 if monster.big else 68)

            * scale

        )



        body_h = int(

            (82 if monster.big else 66)

            * scale

        )



        body = pygame.Rect(

            0,

            0,

            body_w,

            body_h,

        )



        body.center = center

        body_color = COLORS[monster.color]



        # Schatten

        shadow = pygame.Rect(

            0,

            0,

            int(body_w * 0.80),

            max(5, int(12 * scale)),

        )



        shadow.center = (

            cx + int(3 * scale),

            cy + body_h // 2 + int(8 * scale),

        )



        pygame.draw.ellipse(

            self.canvas,

            (205, 211, 220),

            shadow,

        )



        # Schwanz hinter dem Körper

        if tail_style != 0:

            tail_start = (

                body.right - int(5 * scale),

                cy + int(12 * scale),

            )



            if tail_style == 1:

                tail_points = [

                    tail_start,

                    (body.right + int(24 * scale), cy + int(4 * scale)),

                    (body.right + int(30 * scale), cy - int(9 * scale)),

                ]



                pygame.draw.lines(

                    self.canvas,

                    BLACK,

                    False,

                    tail_points,

                    max(2, int(6 * scale)),

                )



                pygame.draw.circle(

                    self.canvas,

                    body_color,

                    tail_points[-1],

                    max(4, int(8 * scale)),

                )



                pygame.draw.circle(

                    self.canvas,

                    BLACK,

                    tail_points[-1],

                    max(4, int(8 * scale)),

                    width=max(1, int(2 * scale)),

                )



            elif tail_style == 2:

                tail_rect = pygame.Rect(

                    body.right - int(4 * scale),

                    cy - int(5 * scale),

                    int(34 * scale),

                    int(34 * scale),

                )



                pygame.draw.arc(

                    self.canvas,

                    BLACK,

                    tail_rect,

                    4.1,

                    6.2,

                    max(2, int(5 * scale)),

                )



            else:

                tail = [

                    tail_start,

                    (body.right + int(28 * scale), cy + int(2 * scale)),

                    (body.right + int(20 * scale), cy + int(17 * scale)),

                ]



                pygame.draw.polygon(

                    self.canvas,

                    body_color,

                    tail,

                )



                pygame.draw.polygon(

                    self.canvas,

                    BLACK,

                    tail,

                    width=max(1, int(2 * scale)),

                )



        # Ohren hinter dem Körper

        if ear_style in (1, 3):

            for side in (-1, 1):

                ear_x = cx + side * int(body_w * 0.34)

                pts = [

                    (ear_x - side * int(11 * scale), body.top + int(14 * scale)),

                    (ear_x, body.top - int(18 * scale)),

                    (ear_x + side * int(12 * scale), body.top + int(13 * scale)),

                ]



                pygame.draw.polygon(self.canvas, body_color, pts)

                pygame.draw.polygon(

                    self.canvas,

                    BLACK,

                    pts,

                    width=max(1, int(2 * scale)),

                )



        elif ear_style == 2:

            for side in (-1, 1):

                ear = pygame.Rect(

                    0,

                    0,

                    int(24 * scale),

                    int(32 * scale),

                )



                ear.center = (

                    cx + side * int(body_w * 0.38),

                    body.top + int(4 * scale),

                )



                pygame.draw.ellipse(self.canvas, body_color, ear)

                pygame.draw.ellipse(

                    self.canvas,

                    BLACK,

                    ear,

                    width=max(1, int(2 * scale)),

                )



        # Antennen sind rein dekorativ und unabhängig von Hörnern/Flügeln.

        if antenna_style != 0:

            antenna_top = body.top - int(18 * scale)



            for side in (-1, 1):

                start = (

                    cx + side * int(10 * scale),

                    body.top + int(5 * scale),

                )



                end = (

                    cx + side * int((16 if antenna_style == 1 else 25) * scale),

                    antenna_top,

                )



                pygame.draw.line(

                    self.canvas,

                    BLACK,

                    start,

                    end,

                    max(1, int(2 * scale)),

                )



                pygame.draw.circle(

                    self.canvas,

                    YELLOW if antenna_style == 1 else ACCENT,

                    end,

                    max(2, int(5 * scale)),

                )



        # Flügel

        if monster.wings:

            wing_w = int(28 * scale)

            wing_h = int(44 * scale)



            left = [

                (body.left, cy - int(8 * scale)),

                (body.left - wing_w, cy - wing_h // 2),

                (body.left - wing_w + int(5 * scale), cy + wing_h // 2),

            ]



            right = [

                (body.right, cy - int(8 * scale)),

                (body.right + wing_w, cy - wing_h // 2),

                (body.right + wing_w - int(5 * scale), cy + wing_h // 2),

            ]



            for wing in (left, right):

                pygame.draw.polygon(

                    self.canvas,

                    (170, 190, 230),

                    wing,

                )



                pygame.draw.polygon(

                    self.canvas,

                    BORDER,

                    wing,

                    width=max(1, int(2 * scale)),

                )



                pygame.draw.line(

                    self.canvas,

                    WHITE,

                    wing[0],

                    wing[2],

                    max(1, int(2 * scale)),

                )



        # Füße

        foot_y = cy + body_h // 2 - int(2 * scale)

        foot_w = max(7, int(22 * scale))

        foot_h = max(5, int(12 * scale))



        for foot_x in (

            cx - body_w // 4,

            cx + body_w // 4,

        ):

            foot = pygame.Rect(0, 0, foot_w, foot_h)

            foot.center = (foot_x, foot_y)

            pygame.draw.ellipse(self.canvas, body_color, foot)

            pygame.draw.ellipse(

                self.canvas,

                BLACK,

                foot,

                width=max(1, int(2 * scale)),

            )



        # Körper

        pygame.draw.ellipse(self.canvas, body_color, body)

        pygame.draw.ellipse(

            self.canvas,

            BLACK,

            body,

            width=max(1, int(2 * scale)),

        )



        # Dekorative Flecken

        if spot_style != 0:

            spot_positions = [

                (-0.23, 0.08, 8),

                (0.25, 0.22, 7),

                (0.08, -0.28, 6),

            ]



            for i, (dx, dy, radius) in enumerate(spot_positions):

                if i >= spot_style:

                    break



                spot_color = (

                    (255, 225, 150)

                    if (style + i) % 2 == 0

                    else (235, 235, 245)

                )



                pygame.draw.circle(

                    self.canvas,

                    spot_color,

                    (

                        cx + int(body_w * dx),

                        cy + int(body_h * dy),

                    ),

                    max(2, int(radius * scale)),

                )



        # Bauchfleck

        belly = pygame.Rect(

            0,

            0,

            int(body_w * 0.52),

            int(body_h * 0.34),

        )



        belly.center = (

            cx,

            cy + int(body_h * 0.20),

        )



        pygame.draw.ellipse(self.canvas, WHITE, belly)

        pygame.draw.ellipse(

            self.canvas,

            BORDER,

            belly,

            width=max(1, int(1 * scale)),

        )



        # Glanzpunkt

        pygame.draw.ellipse(

            self.canvas,

            WHITE,

            pygame.Rect(

                body.left + int(12 * scale),

                body.top + int(14 * scale),

                max(5, int(13 * scale)),

                max(3, int(7 * scale)),

            ),

        )



        # Hörner als echtes Entscheidungsmerkmal

        if monster.horns:

            top = body.top + int(7 * scale)

            horn_h = int(26 * scale)

            horn_w = int(13 * scale)



            for offset in (-body_w // 4, body_w // 4):

                pts = [

                    (cx + offset - horn_w, top + horn_h),

                    (cx + offset, top - horn_h // 2),

                    (cx + offset + horn_w, top + horn_h),

                ]



                pygame.draw.polygon(self.canvas, YELLOW, pts)

                pygame.draw.polygon(

                    self.canvas,

                    BLACK,

                    pts,

                    width=max(1, int(2 * scale)),

                )



        # Unterschiedliche Augenformen

        eye_y = cy - int(12 * scale)

        eye_dx = int(16 * scale)



        for side, ex in ((-1, cx - eye_dx), (1, cx + eye_dx)):

            if eye_style == 0:

                eye = pygame.Rect(

                    0,

                    0,

                    max(8, int(19 * scale)),

                    max(8, int(19 * scale)),

                )



                eye.center = (ex, eye_y)

                pygame.draw.ellipse(self.canvas, WHITE, eye)



            elif eye_style == 1:

                eye = pygame.Rect(

                    0,

                    0,

                    max(7, int(15 * scale)),

                    max(10, int(23 * scale)),

                )



                eye.center = (ex, eye_y)

                pygame.draw.ellipse(self.canvas, WHITE, eye)



            elif eye_style == 2:

                eye = pygame.Rect(

                    0,

                    0,

                    max(9, int(22 * scale)),

                    max(6, int(14 * scale)),

                )



                eye.center = (ex, eye_y)

                pygame.draw.ellipse(self.canvas, WHITE, eye)



            else:

                pygame.draw.line(

                    self.canvas,

                    BLACK,

                    (ex - int(8 * scale), eye_y),

                    (ex + int(8 * scale), eye_y + side * int(2 * scale)),

                    max(2, int(3 * scale)),

                )



                eye = None



            if eye is not None:

                pupil_x = ex + int(((style + side) % 3 - 1) * 2 * scale)



                pygame.draw.circle(

                    self.canvas,

                    BLACK,

                    (pupil_x, eye_y + int(2 * scale)),

                    max(2, int(5 * scale)),

                )



                pygame.draw.circle(

                    self.canvas,

                    WHITE,

                    (pupil_x - max(1, int(2 * scale)), eye_y),

                    max(1, int(2 * scale)),

                )



        # Mundform ebenfalls nur dekorativ

        mouth_rect = pygame.Rect(

            cx - int(18 * scale),

            cy + int(7 * scale),

            int(36 * scale),

            int(23 * scale),

        )



        if mouth_style == 0:

            pygame.draw.arc(

                self.canvas,

                BLACK,

                mouth_rect,

                0.15,

                2.95,

                max(2, int(3 * scale)),

            )



        elif mouth_style == 1:

            pygame.draw.line(

                self.canvas,

                BLACK,

                (cx - int(14 * scale), cy + int(18 * scale)),

                (cx + int(14 * scale), cy + int(18 * scale)),

                max(2, int(3 * scale)),

            )



        else:

            pygame.draw.arc(

                self.canvas,

                BLACK,

                mouth_rect,

                3.35,

                6.05,

                max(2, int(3 * scale)),

            )



        # Unterschiedliche Zähne; ebenfalls unabhängig von der Klasse

        if tooth_style != 0:

            tooth_count = 1 if tooth_style == 1 else 2

            tooth_y = cy + int(18 * scale)



            for i in range(tooth_count):

                tooth_x = (

                    cx

                    if tooth_count == 1

                    else cx + (-1 if i == 0 else 1) * int(9 * scale)

                )



                if tooth_style == 3:

                    tooth = pygame.Rect(

                        0,

                        0,

                        max(4, int(7 * scale)),

                        max(5, int(9 * scale)),

                    )



                    tooth.midtop = (tooth_x, tooth_y)

                    pygame.draw.rect(self.canvas, WHITE, tooth, border_radius=1)

                    pygame.draw.rect(

                        self.canvas,

                        BLACK,

                        tooth,

                        width=1,

                        border_radius=1,

                    )



                else:

                    tooth = [

                        (tooth_x - int(3 * scale), tooth_y),

                        (tooth_x + int(3 * scale), tooth_y),

                        (tooth_x, tooth_y + max(4, int(8 * scale))),

                    ]



                    pygame.draw.polygon(self.canvas, WHITE, tooth)

                    pygame.draw.polygon(

                        self.canvas,

                        BLACK,

                        tooth,

                        width=1,

                    )



        # Kleine Accessoires

        if accessory_style == 1:

            # Fliege

            bow_y = body.bottom - int(17 * scale)

            left_bow = [

                (cx - int(4 * scale), bow_y),

                (cx - int(18 * scale), bow_y - int(7 * scale)),

                (cx - int(18 * scale), bow_y + int(7 * scale)),

            ]



            right_bow = [

                (cx + int(4 * scale), bow_y),

                (cx + int(18 * scale), bow_y - int(7 * scale)),

                (cx + int(18 * scale), bow_y + int(7 * scale)),

            ]



            pygame.draw.polygon(self.canvas, ACCENT, left_bow)

            pygame.draw.polygon(self.canvas, ACCENT, right_bow)

            pygame.draw.circle(

                self.canvas,

                YELLOW,

                (cx, bow_y),

                max(2, int(5 * scale)),

            )



        elif accessory_style == 2:

            # Kleine Kappe

            hat = pygame.Rect(

                0,

                0,

                int(38 * scale),

                int(13 * scale),

            )



            hat.midbottom = (cx, body.top + int(2 * scale))

            pygame.draw.rect(

                self.canvas,

                ACCENT,

                hat,

                border_radius=max(1, int(4 * scale)),

            )



            pygame.draw.line(

                self.canvas,

                BLACK,

                (hat.left - int(3 * scale), hat.bottom),

                (hat.right + int(9 * scale), hat.bottom),

                max(1, int(2 * scale)),

            )



        elif accessory_style == 3:

            # Monokel

            mono_x = cx + eye_dx

            pygame.draw.circle(

                self.canvas,

                YELLOW,

                (mono_x, eye_y),

                max(6, int(13 * scale)),

                width=max(1, int(2 * scale)),

            )



            pygame.draw.line(

                self.canvas,

                YELLOW,

                (mono_x + int(9 * scale), eye_y + int(9 * scale)),

                (body.right - int(3 * scale), cy + int(24 * scale)),

                max(1, int(2 * scale)),

            )



        elif accessory_style == 4:

            # Schal

            scarf = pygame.Rect(

                body.left + int(7 * scale),

                body.bottom - int(28 * scale),

                body_w - int(14 * scale),

                max(5, int(9 * scale)),

            )



            pygame.draw.rect(

                self.canvas,

                (235, 120, 88),

                scarf,

                border_radius=max(1, int(4 * scale)),

            )



            pygame.draw.line(

                self.canvas,

                (235, 120, 88),

                (scarf.right - int(8 * scale), scarf.bottom),

                (scarf.right + int(5 * scale), scarf.bottom + int(16 * scale)),

                max(2, int(5 * scale)),

            )



        elif accessory_style == 5:

            # Stern-Abzeichen

            badge_center = (

                cx + int(body_w * 0.23),

                cy + int(body_h * 0.18),

            )



            badge_r = max(3, int(7 * scale))

            points = []



            for i in range(10):

                angle = -1.5708 + i * 0.62832

                radius = badge_r if i % 2 == 0 else badge_r * 0.45

                points.append(

                    (

                        int(badge_center[0] + radius * math.cos(angle)),

                        int(badge_center[1] + radius * math.sin(angle)),

                    )

                )



            pygame.draw.polygon(self.canvas, YELLOW, points)

            pygame.draw.polygon(self.canvas, BLACK, points, width=1)



    # --------------------------------------------------------

    # HEADER

    # --------------------------------------------------------



    def header(self) -> None:

        canvas_width = self.canvas.get_width()

        pygame.draw.rect(
            self.canvas,
            PANEL,
            (0, 0, canvas_width, 100),
        )



        pygame.draw.line(
            self.canvas,
            BORDER,
            (0, 99),
            (canvas_width, 99),
            2,
        )



        self.text(

            self.big,

            "Monster-Detektiv",

            (28, 18),

        )



        phase_names = [

            "Trainingsmonster kennenlernen",

            "Random Forest bauen",

            "Neue Monster testen",

        ]



        self.text(

            self.font,

            f"Phase {self.phase}: "

            f"{phase_names[self.phase - 1]}",

            (30, 58),

            MUTED,

        )



        start_x = 720



        for n in (

            1,

            2,

            3,

        ):

            cx = (

                start_x

                + (n - 1) * 135

            )



            done = n < self.phase

            active = n == self.phase



            if done:

                color = GOOD

            elif active:

                color = ACCENT

            else:

                color = BORDER



            pygame.draw.circle(

                self.canvas,

                color,

                (cx, 48),

                20,

            )



            self.centered(

                self.bold,

                str(n),

                (cx, 48),

                WHITE

                if done or active

                else TEXT,

            )



            if n < 3:

                pygame.draw.line(

                    self.canvas,

                    GOOD

                    if done

                    else BORDER,

                    (

                        cx + 22,

                        48,

                    ),

                    (

                        cx + 112,

                        48,

                    ),

                    4,

                )



        for i, lab in enumerate(

            (

                "Training",

                "Wald",

                "Test",

            )

        ):

            self.centered(

                self.tiny,

                lab,

                (

                    start_x

                    + i * 135,

                    78,

                ),

                MUTED,

            )



    # --------------------------------------------------------

    # PHASE 1

    # --------------------------------------------------------



    def card_rect(

        self,

        i: int,

    ) -> pygame.Rect:



        return pygame.Rect(

            28 + (i % 4) * 196,

            150 + (i // 4) * 175,

            176,

            155,

        )



    def phase1(self) -> None:

        self.text(

            self.bold,

            "Klicke die Monster an und entdecke ihre Merkmale.",

            (28, 115),

        )



        for i, monster in enumerate(TRAINING[:12]):

            rect = self.card_rect(i)



            selected = (

                i

                == self.selected_training

            )



            pygame.draw.rect(

                self.canvas,

                ACCENT_LIGHT

                if selected

                else PANEL,

                rect,

                border_radius=12,

            )



            pygame.draw.rect(

                self.canvas,

                ACCENT

                if selected

                else BORDER,

                rect,

                width=3

                if selected

                else 2,

                border_radius=12,

            )



            self.draw_monster(

                monster,

                (

                    rect.centerx,

                    rect.top + 62,

                ),

                0.68,

            )



            self.centered(

                self.bold,

                monster.name,

                (

                    rect.centerx,

                    rect.bottom - 38,

                ),

            )



            # In der Challenge-Version wird die Klasse nicht auf jeder Karte
            # verraten. Sie erscheint erst in der Infobox des angeklickten Monsters.
            self.centered(
                self.tiny,
                "anklicken zum Untersuchen",
                (rect.centerx, rect.bottom - 17),
                MUTED,
            )



        # Infobox

        info = pygame.Rect(

            820,

            140,

            330,

            460,

        )



        pygame.draw.rect(

            self.canvas,

            PANEL,

            info,

            border_radius=14,

        )



        pygame.draw.rect(

            self.canvas,

            BORDER,

            info,

            width=2,

            border_radius=14,

        )



        m = TRAINING[

            self.selected_training

        ]



        self.centered(

            self.big,

            m.name,

            (

                info.centerx,

                info.top + 34,

            ),

        )



        self.draw_monster(

            m,

            (

                info.centerx,

                info.top + 150,

            ),

            1.1,

        )



        props = [

            (

                "Farbe",

                m.color,

            ),

            (

                "Hörner",

                "ja"

                if m.horns

                else "nein",

            ),

            (

                "Flügel",

                "ja"

                if m.wings

                else "nein",

            ),

            (

                "Größe",

                "groß"

                if m.big

                else "klein",

            ),

            (

                "Antennen",

                "ja"

                if m.antennae

                else "nein",

            ),

        ]



        y = info.top + 245



        for k, v in props:

            self.text(

                self.font,

                k + ":",

                (

                    info.left + 30,

                    y,

                ),

                MUTED,

            )



            self.text(

                self.bold,

                v,

                (

                    info.left + 145,

                    y,

                ),

            )



            y += 34



        self.text(

            self.font,

            "Klasse:",

            (

                info.left + 30,

                y + 8,

            ),

            MUTED,

        )



        self.text(

            self.bold,

            m.label,

            (

                info.left + 145,

                y + 8,

            ),

            BAD

            if m.label == "gefährlich"

            else GOOD,

        )



        self.wrap(

            self.small,

            "Diese Beispiele sind die Trainingsdaten. "

            "Aus ihnen sollen deine Bäume im Random Forest lernen.",

            pygame.Rect(

                info.left + 25,

                info.bottom + 10,

                info.width - 50,

                60,

            ),

        )



    # --------------------------------------------------------
    # RANDOM-FOREST-BAEUME
    # --------------------------------------------------------

    def _bootstrap_sample(self, tree_index: int) -> List[Monster]:
        """Feste, aber unterschiedliche Bootstrap-Stichprobe je Baum."""
        rng = random.Random(1847 + (tree_index + 1) * 7919)
        return [rng.choice(TRAINING) for _ in range(len(TRAINING))]

    def _make_forest_member(self, tree_index: int) -> ForestMember:
        sample = self._bootstrap_sample(tree_index)
        return ForestMember(
            sample=sample,
            tree=ForestTree(sample, TreeNode()),
        )

    def _create_initial_forest(self) -> None:
        self.forest_members = [
            self._make_forest_member(i)
            for i in range(self.num_trees)
        ]

    def save_active_tree_scroll(self) -> None:
        if not self.forest_members:
            return
        member = self.forest_members[self.active_tree_index]
        member.scroll_x = self.tree_scroll_x
        member.scroll_y = self.tree_scroll_y

    def activate_tree(self, index: int) -> None:
        if not self.forest_members:
            return

        if hasattr(self, "tree_scroll_x"):
            self.save_active_tree_scroll()

        self.active_tree_index = max(
            0,
            min(index, len(self.forest_members) - 1),
        )
        member = self.forest_members[self.active_tree_index]
        self.tree = member.tree
        self.tree_root = self.tree.root
        self.tree_scroll_x = member.scroll_x
        self.tree_scroll_y = member.scroll_y
        self.tree_scroll_drag = None
        self.tree_scroll_drag_offset = 0
        self.context_leaf_path = None
        self.context_menu_pos = None

    def resize_forest(self, new_count: int) -> None:
        new_count = max(2, int(new_count))
        self.save_active_tree_scroll()

        while len(self.forest_members) < new_count:
            self.forest_members.append(
                self._make_forest_member(len(self.forest_members))
            )

        if len(self.forest_members) > new_count:
            self.forest_members = self.forest_members[:new_count]

        self.num_trees = new_count
        self.active_tree_index = min(
            self.active_tree_index,
            self.num_trees - 1,
        )
        self.activate_tree(self.active_tree_index)

    def reset_current_tree(self) -> None:
        member = self.forest_members[self.active_tree_index]
        member.tree = ForestTree(member.sample, TreeNode())
        member.scroll_x = 0
        member.scroll_y = 0
        self.activate_tree(self.active_tree_index)

    def reset_forest(self) -> None:
        active = min(self.active_tree_index, self.num_trees - 1)
        self._create_initial_forest()
        self.active_tree_index = 0
        self.tree = self.forest_members[0].tree
        self.tree_root = self.tree.root
        self.tree_scroll_x = 0
        self.tree_scroll_y = 0
        self.tree_scroll_drag = None
        self.context_leaf_path = None
        self.context_menu_pos = None
        self.activate_tree(active)

    def candidate_features(
        self,
        path: Tuple[bool, ...],
    ) -> List[str]:
        """Alle Merkmale bleiben bei jedem Blatt als Frage auswählbar."""
        return list(FEATURES)

    def forest_votes(
        self,
        monster: Monster,
    ) -> Tuple[int, int, List[str], List[List[Tuple[str, bool]]]]:
        votes: List[str] = []
        paths: List[List[Tuple[str, bool]]] = []

        for member in self.forest_members:
            label, path = member.tree.predict(monster)
            votes.append(label)
            paths.append(path)

        dangerous = sum(v == "gefährlich" for v in votes)
        friendly = len(votes) - dangerous
        return dangerous, friendly, votes, paths

    def forest_predict(self, monster: Monster) -> str:
        dangerous, friendly, _votes, _paths = self.forest_votes(monster)
        # Wie vorher: Bei Gleichstand gewinnt freundlich.
        return "gefährlich" if dangerous > friendly else "freundlich"

    def forest_accuracy(self, items: Sequence[Monster]) -> float:
        if not items:
            return 0.0
        correct = sum(
            self.forest_predict(monster) == monster.label
            for monster in items
        )
        return correct / len(items)

    def forest_question_count(self) -> int:
        return sum(
            1
            for member in self.forest_members
            for _path, node, _depth in member.tree.iter_nodes()
            if not node.is_leaf
        )

    def max_tree_leaf_count(self) -> int:
        if not self.forest_members:
            return 0
        return max(
            member.tree.leaf_count()
            for member in self.forest_members
        )

    def can_split_active_tree(self) -> bool:
        # Jeder Split ersetzt ein Blatt durch zwei neue Blaetter und erhoeht
        # die Blattzahl damit genau um 1. Das harte Limit ist max_features.
        return self.tree.leaf_count() < self.max_features

    def all_trees_started(self) -> bool:
        # Bei Blatt-Limit 1 besteht jeder Baum absichtlich nur aus einem Blatt.
        if self.max_features == 1:
            return True
        return all(
            not member.tree.root.is_leaf
            for member in self.forest_members
        )

    def cycle_leaf(
        self,
        key: Tuple[bool, ...],
    ) -> None:
        self.tree.cycle_leaf(key)

    def leaf_explanation(
        self,
        path: Tuple[bool, ...],
        label: str,
        manual: bool,
    ) -> str:
        dangerous, friendly = self.tree.leaf_counts(path)
        mode = "manuell" if manual else "automatisch"

        if dangerous + friendly == 0 and not manual:
            mode = "Fallback"

        return (
            f"{dangerous} gefährlich\n"
            f"{friendly} freundlich\n"
            f"→ {label} · {mode}"
        )

    def node(
        self,
        center: Tuple[int, int],
        txt: str,
        kind: str,
        subtext: Optional[str] = None,
    ) -> pygame.Rect:
        if kind == "q":
            size = (180, 58)
        else:
            size = (160, 88)

        rect = pygame.Rect(0, 0, *size)
        rect.center = center

        if kind == "q":
            fill = ACCENT_LIGHT
            border = ACCENT
        elif kind == "danger":
            fill = BAD_LIGHT
            border = BAD
        else:
            fill = GOOD_LIGHT
            border = GOOD

        pygame.draw.rect(
            self.canvas,
            fill,
            rect,
            border_radius=12,
        )
        pygame.draw.rect(
            self.canvas,
            border,
            rect,
            width=2,
            border_radius=12,
        )

        if subtext:
            lines = subtext.split("\n")
            self.centered(
                self.small,
                txt,
                (center[0], center[1] - 28),
            )

            y = center[1] - 7
            for line in lines:
                self.centered(
                    self.tiny,
                    line,
                    (center[0], y),
                    MUTED,
                )
                y += 15
        else:
            self.centered(
                self.small,
                txt,
                center,
            )

        return rect

    def branch(
        self,
        a: Tuple[int, int],
        b: Tuple[int, int],
        answer: bool,
    ) -> None:
        pygame.draw.line(
            self.canvas,
            BORDER,
            a,
            b,
            3,
        )

        mid = (
            (a[0] + b[0]) // 2,
            (a[1] + b[1]) // 2,
        )

        bubble = pygame.Rect(0, 0, 46, 24)
        bubble.center = mid
        color = GOOD if answer else BAD

        pygame.draw.rect(
            self.canvas,
            WHITE,
            bubble,
            border_radius=10,
        )
        pygame.draw.rect(
            self.canvas,
            color,
            bubble,
            width=2,
            border_radius=10,
        )
        self.centered(
            self.tiny,
            "JA" if answer else "NEIN",
            mid,
            color,
        )

    def tree_layout(
        self,
    ) -> Tuple[
        Dict[Tuple[bool, ...], Tuple[int, int]],
        int,
        int,
    ]:
        positions: Dict[
            Tuple[bool, ...],
            Tuple[int, int],
        ] = {}

        leaf_index = 0
        max_depth = 0
        leaf_spacing = 190
        level_spacing = 145
        margin_x = 95
        margin_y = 55

        def walk(
            node: TreeNode,
            path: Tuple[bool, ...],
            depth: int,
        ) -> int:
            nonlocal leaf_index, max_depth
            max_depth = max(max_depth, depth)

            if node.is_leaf:
                x = margin_x + leaf_index * leaf_spacing
                leaf_index += 1
            else:
                assert node.yes is not None
                assert node.no is not None
                yes_x = walk(
                    node.yes,
                    path + (True,),
                    depth + 1,
                )
                no_x = walk(
                    node.no,
                    path + (False,),
                    depth + 1,
                )
                x = (yes_x + no_x) // 2

            positions[path] = (
                x,
                margin_y + depth * level_spacing,
            )
            return x

        walk(self.tree.root, (), 0)

        leaves = max(1, leaf_index)
        width = max(190, margin_x * 2 + (leaves - 1) * leaf_spacing)
        height = margin_y * 2 + max_depth * level_spacing + 90
        return positions, width, height

    def draw_recursive_tree(
        self,
        view: pygame.Rect,
    ) -> None:
        positions, virtual_w, virtual_h = self.tree_layout()

        max_scroll_x = max(0, virtual_w - view.width)
        max_scroll_y = max(0, virtual_h - view.height)
        self.tree_scroll_x = max(
            0,
            min(self.tree_scroll_x, max_scroll_x),
        )
        self.tree_scroll_y = max(
            0,
            min(self.tree_scroll_y, max_scroll_y),
        )
        self.tree_scroll_limits = (max_scroll_x, max_scroll_y)

        if virtual_w <= view.width:
            origin_x = view.left + (view.width - virtual_w) // 2
        else:
            origin_x = view.left - self.tree_scroll_x

        if virtual_h <= view.height:
            origin_y = view.top + (view.height - virtual_h) // 2
        else:
            origin_y = view.top - self.tree_scroll_y

        def screen_pos(
            path: Tuple[bool, ...],
        ) -> Tuple[int, int]:
            x, y = positions[path]
            return origin_x + x, origin_y + y

        self.canvas.set_clip(view)

        for path, node, _depth in self.tree.iter_nodes():
            if node.is_leaf:
                continue

            parent = screen_pos(path)

            for answer in (True, False):
                child_path = path + (answer,)
                if child_path not in positions:
                    continue

                child_node = self.tree.node_at(child_path)
                if child_node is None:
                    continue

                child = screen_pos(child_path)
                child_top = 29 if not child_node.is_leaf else 44

                self.branch(
                    (parent[0], parent[1] + 29),
                    (child[0], child[1] - child_top),
                    answer,
                )

        for path, node, _depth in self.tree.iter_nodes():
            center = screen_pos(path)

            if node.is_leaf:
                label = self.tree.leaf_label(path)
                manual = node.override is not None
                rect = self.node(
                    center,
                    label,
                    "danger"
                    if label == "gefährlich"
                    else "friendly",
                    self.leaf_explanation(
                        path,
                        label,
                        manual,
                    ),
                )

                if rect.colliderect(view):
                    self.leaf_hitboxes[path] = rect
            else:
                assert node.feature is not None
                self.node(
                    center,
                    FEATURE_LABELS[node.feature],
                    "q",
                )

        self.canvas.set_clip(None)

    def context_menu_rect(self) -> Optional[pygame.Rect]:
        if (
            self.context_leaf_path is None
            or self.context_menu_pos is None
        ):
            return None

        candidates = self.candidate_features(self.context_leaf_path)
        width = 224
        # Zusaetzlich Platz fuer "Blatt loeschen" und "Abbrechen".
        height = 48 + len(candidates) * 38 + 76
        x, y = self.context_menu_pos

        if self.tree_view_rect.width > 0:
            min_x = self.tree_view_rect.left + 4
            max_x = self.tree_view_rect.right - width - 4
            min_y = self.tree_view_rect.top + 4
            max_y = self.tree_view_rect.bottom - height - 4
        else:
            min_x = 8
            max_x = WIDTH - width - 8
            min_y = 108
            max_y = HEIGHT - height - 8

        x = max(min_x, min(x, max_x))
        y = max(min_y, min(y, max_y))
        return pygame.Rect(x, y, width, height)

    def draw_context_menu(self) -> None:
        menu = self.context_menu_rect()
        if menu is None:
            return

        pygame.draw.rect(
            self.canvas,
            PANEL,
            menu,
            border_radius=12,
        )
        pygame.draw.rect(
            self.canvas,
            ACCENT,
            menu,
            width=2,
            border_radius=12,
        )
        self.text(
            self.bold,
            "Blatt aufteilen",
            (menu.left + 12, menu.top + 8),
        )
        leaf_count = self.tree.leaf_count()
        if self.can_split_active_tree():
            menu_info = (
                f"Alle {len(FEATURES)} wählbar · "
                f"Blätter {leaf_count}/{self.max_features}"
            )
        else:
            menu_info = (
                f"Blatt-Limit erreicht: {leaf_count}/{self.max_features}"
            )
        self.text(
            self.tiny,
            menu_info,
            (menu.left + 12, menu.top + 29),
            BAD if not self.can_split_active_tree() else MUTED,
        )

    # --------------------------------------------------------
    # PHASE 2
    # --------------------------------------------------------

    def phase2(self) -> None:
        self.leaf_hitboxes = {}

        # In Phase 2 wird die komplette 1440 x 950-Flaeche genutzt.
        # Schrift-, Knoten- und Button-Groessen bleiben unveraendert; nur die
        # Arbeitsflaeche fuer den Baum ist deutlich groesser.
        area = pygame.Rect(24, 122, 1080, 790)
        control_x = 1130
        control_center_x = 1270

        pygame.draw.rect(
            self.canvas,
            PANEL,
            area,
            border_radius=14,
        )
        pygame.draw.rect(
            self.canvas,
            BORDER,
            area,
            width=2,
            border_radius=14,
        )

        self.text(
            self.bold,
            f"Baum {self.active_tree_index + 1} von {self.num_trees} – selbst bauen",
            (area.left + 22, area.top + 18),
        )
        self.text(
            self.tiny,
            "Rechtsklick: Blatt teilen · Mausrad: scrollen · Shift: seitlich",
            (area.left + 445, area.top + 21),
            MUTED,
        )

        scroll_area = pygame.Rect(
            area.left + 10,
            area.top + 50,
            area.width - 20,
            area.height - 145,
        )
        view = pygame.Rect(
            scroll_area.left,
            scroll_area.top,
            scroll_area.width - 16,
            scroll_area.height - 16,
        )
        self.tree_view_rect = view

        pygame.draw.rect(
            self.canvas,
            PANEL_ALT,
            scroll_area,
            border_radius=10,
        )

        self.draw_recursive_tree(view)
        self.draw_tree_scrollbars(view)

        tree_acc = self.tree.accuracy(TRAINING)
        forest_acc = self.forest_accuracy(TRAINING)
        tree_leaves = self.tree.leaf_count()

        box = pygame.Rect(
            area.left + 24,
            area.bottom - 70,
            300,
            42,
        )
        pygame.draw.rect(
            self.canvas,
            PANEL_ALT,
            box,
            border_radius=10,
        )
        self.centered(
            self.small,
            (
                f"Baum: {tree_acc * 100:.0f}% | "
                f"{tree_leaves}/{self.max_features} Blätter"
            ),
            box.center,
        )

        self.wrap(
            self.small,
            f"Gesamter Wald: {forest_acc * 100:.0f}% Trainingsgenauigkeit. "
            "Jeder Baum besitzt eine eigene Bootstrap-Stichprobe und stimmt später einzeln ab.",
            pygame.Rect(
                area.left + 350,
                area.bottom - 78,
                area.width - 385,
                65,
            ),
            MUTED,
        )

        # Rechte Bedienleiste
        self.text(self.bold, "Random Forest", (control_x, 118))

        self.text(
            self.small,
            "Anzahl der Bäume (min. 2)",
            (control_x, 153),
            MUTED,
        )
        self.centered(
            self.big,
            str(self.num_trees),
            (control_center_x, 202),
            ACCENT,
        )

        self.text(
            self.small,
            "Merkmale pro Split / Blatt-Limit",
            (control_x, 248),
            MUTED,
        )
        self.wrap(
            self.tiny,
            f"Alle {len(FEATURES)} Fragen bleiben auswählbar. Diese Zahl ist zugleich die maximale Blattzahl pro Baum.",
            pygame.Rect(control_x, 270, 270, 58),
        )

        self.text(self.small, "Aktiver Baum", (control_x, 357), MUTED)
        self.centered(
            self.bold,
            f"{self.active_tree_index + 1} / {self.num_trees}",
            (control_center_x, 402),
            ACCENT,
        )

        member = self.forest_members[self.active_tree_index]
        unique = len({m.name for m in member.sample})
        self.wrap(
            self.tiny,
            f"Bootstrap: {len(member.sample)} Ziehungen, {unique} verschiedene Trainingsmonster. "
            "Baue jeden Baum unabhängig auf.",
            pygame.Rect(control_x, 430, 270, 62),
        )

        self.text(self.bold, "So baust du", (control_x, 505))
        self.wrap(
            self.small,
            "Rechtsklick auf ein Blatt → alle Merkmale sehen → Frage frei wählen. "
            "Linksklick ändert die Klasse des Blatts.",
            pygame.Rect(control_x, 535, 270, 78),
        )

        if not self.all_trees_started():
            missing = sum(
                member.tree.root.is_leaf
                for member in self.forest_members
            )
            self.text(
                self.tiny,
                f"Noch {missing} Baum/Bäume ohne erste Frage.",
                (control_x, 720),
                BAD,
            )

        self.draw_context_menu()

    # --------------------------------------------------------

    # TEST RESET

    # --------------------------------------------------------



    def reset_test(self) -> None:
        self.test_index = 0
        self.prediction = None
        self.vote_dangerous = 0
        self.vote_friendly = 0
        self.individual_votes = []
        self.individual_paths = []
        self.score = 0
        self.test_finished = False
        self.answered.clear()

    def reset_game(self) -> None:
        self.phase = 1
        self.selected_training = 0
        self.num_trees = 3
        self.max_features = 2
        self.active_tree_index = 0
        self._create_initial_forest()
        self.tree = self.forest_members[0].tree
        self.tree_root = self.tree.root
        self.tree_scroll_x = 0
        self.tree_scroll_y = 0
        self.context_leaf_path = None
        self.context_menu_pos = None
        self.reset_test()

    def phase3_finished(self) -> None:
        panel = pygame.Rect(135, 135, 910, 565)

        pygame.draw.rect(
            self.canvas,
            PANEL,
            panel,
            border_radius=18,
        )
        pygame.draw.rect(
            self.canvas,
            ACCENT,
            panel,
            width=3,
            border_radius=18,
        )

        self.centered(
            self.huge,
            "Random-Forest-Test abgeschlossen!",
            (panel.centerx, panel.top + 58),
            ACCENT,
        )
        self.centered(
            self.big,
            f"{self.score}/{len(TEST_DATA)} richtig",
            (panel.centerx, panel.top + 125),
        )

        accuracy = self.score / len(TEST_DATA) if TEST_DATA else 0.0
        percent = int(round(accuracy * 100))
        total_questions = self.forest_question_count()

        score_box = pygame.Rect(
            panel.centerx - 175,
            panel.top + 160,
            350,
            92,
        )
        pygame.draw.rect(
            self.canvas,
            PANEL_ALT,
            score_box,
            border_radius=14,
        )
        self.centered(
            self.huge,
            f"{percent}%",
            (score_box.centerx, score_box.centery - 7),
            GOOD if accuracy >= 0.8 else ACCENT,
        )
        self.centered(
            self.tiny,
            f"{self.num_trees} selbst gebaute Bäume | {total_questions} Fragen insgesamt",
            (score_box.centerx, score_box.bottom - 17),
            MUTED,
        )

        if accuracy >= 0.95:
            message = (
                "Stark! Deine selbst gebauten Bäume ergänzen sich sehr gut. "
                "Versuche, mit anderen Merkmalsauswahlen ähnlich genau zu bleiben."
            )
        elif accuracy >= 0.75:
            message = (
                "Schon ziemlich gut. Wechsle zwischen den Bäumen und verbessere "
                "besonders die Blätter mit gemischten Trainingsmonstern."
            )
        else:
            message = (
                "Der Wald kann noch besser werden. Jeder Baum darf anders aussehen: "
                "Probiere unterschiedliche Fragen und verbessere mehrere Bäume."
            )

        self.wrap(
            self.font,
            message,
            pygame.Rect(
                panel.left + 205,
                panel.top + 285,
                panel.width - 410,
                100,
            ),
            TEXT,
        )

        if TEST_DATA:
            sample_ids = (0, len(TEST_DATA) // 2, len(TEST_DATA) - 1)
            sample_x = (panel.left + 125, panel.centerx, panel.right - 125)
            for idx, x in zip(sample_ids, sample_x):
                self.draw_monster(
                    TEST_DATA[idx],
                    (x, panel.top + 415),
                    0.95,
                )

        self.centered(
            self.small,
            "Wie möchtest du weitermachen?",
            (panel.centerx, panel.bottom - 82),
            MUTED,
        )

    # --------------------------------------------------------
    # PHASE 3
    # --------------------------------------------------------

    def phase3(self) -> None:
        if self.test_finished:
            self.phase3_finished()
            return

        m = TEST_DATA[self.test_index]

        left = pygame.Rect(24, 122, 470, 610)
        center = pygame.Rect(515, 122, 305, 610)
        right = pygame.Rect(840, 122, 316, 610)

        for rect in (left, center, right):
            pygame.draw.rect(
                self.canvas,
                PANEL,
                rect,
                border_radius=14,
            )
            pygame.draw.rect(
                self.canvas,
                BORDER,
                rect,
                width=2,
                border_radius=14,
            )

        # Testmonster
        self.centered(
            self.big,
            f"Testmonster {self.test_index + 1}/{len(TEST_DATA)}",
            (left.centerx, left.top + 35),
        )
        self.draw_monster(
            m,
            (left.centerx, left.top + 200),
            1.55,
        )
        self.centered(
            self.big,
            m.name,
            (left.centerx, left.top + 330),
        )

        props = [
            f"Farbe: {m.color}",
            "Hörner: " + ("ja" if m.horns else "nein"),
            "Flügel: " + ("ja" if m.wings else "nein"),
            "Größe: " + ("groß" if m.big else "klein"),
            "Antennen: " + ("ja" if m.antennae else "nein"),
        ]
        y = left.top + 390
        for prop in props:
            self.centered(
                self.font,
                prop,
                (left.centerx, y),
            )
            y += 32

        # Stimmen des Waldes
        self.centered(
            self.big,
            "Stimmen der Bäume",
            (center.centerx, center.top + 35),
        )

        if self.prediction is None:
            self.wrap(
                self.font,
                "Drücke „Wald entscheiden“. Jeder deiner selbst gebauten Bäume "
                "klassifiziert das Monster einzeln. Danach entscheidet die Mehrheit.",
                pygame.Rect(
                    center.left + 24,
                    center.top + 100,
                    center.width - 48,
                    150,
                ),
            )
        else:
            danger_box = pygame.Rect(
                center.left + 24,
                center.top + 88,
                118,
                74,
            )
            friendly_box = pygame.Rect(
                center.right - 142,
                center.top + 88,
                118,
                74,
            )

            pygame.draw.rect(
                self.canvas,
                BAD_LIGHT,
                danger_box,
                border_radius=12,
            )
            pygame.draw.rect(
                self.canvas,
                GOOD_LIGHT,
                friendly_box,
                border_radius=12,
            )
            pygame.draw.rect(
                self.canvas,
                BAD,
                danger_box,
                width=2,
                border_radius=12,
            )
            pygame.draw.rect(
                self.canvas,
                GOOD,
                friendly_box,
                width=2,
                border_radius=12,
            )

            self.centered(
                self.huge,
                str(self.vote_dangerous),
                (danger_box.centerx, danger_box.centery - 8),
                BAD,
            )
            self.centered(
                self.tiny,
                "gefährlich",
                (danger_box.centerx, danger_box.bottom - 15),
                BAD,
            )
            self.centered(
                self.huge,
                str(self.vote_friendly),
                (friendly_box.centerx, friendly_box.centery - 8),
                GOOD,
            )
            self.centered(
                self.tiny,
                "freundlich",
                (friendly_box.centerx, friendly_box.bottom - 15),
                GOOD,
            )

            # Einzelstimmen. Bei vielen Bäumen nur so viele anzeigen, wie passen.
            list_top = center.top + 190
            max_visible = 9
            for i, vote in enumerate(self.individual_votes[:max_visible]):
                row = pygame.Rect(
                    center.left + 32,
                    list_top + i * 29,
                    center.width - 64,
                    24,
                )
                pygame.draw.rect(
                    self.canvas,
                    BAD_LIGHT if vote == "gefährlich" else GOOD_LIGHT,
                    row,
                    border_radius=8,
                )
                self.text(
                    self.tiny,
                    f"Baum {i + 1}",
                    (row.left + 8, row.top + 5),
                    MUTED,
                )
                label_img = self.tiny.render(
                    vote,
                    True,
                    BAD if vote == "gefährlich" else GOOD,
                )
                self.canvas.blit(
                    label_img,
                    label_img.get_rect(
                        midright=(row.right - 8, row.centery)
                    ),
                )

            if len(self.individual_votes) > max_visible:
                self.centered(
                    self.tiny,
                    f"+ {len(self.individual_votes) - max_visible} weitere Bäume",
                    (center.centerx, list_top + max_visible * 29 + 8),
                    MUTED,
                )

            result = pygame.Rect(
                center.left + 36,
                center.bottom - 100,
                center.width - 72,
                72,
            )
            result_color = BAD if self.prediction == "gefährlich" else GOOD
            result_fill = BAD_LIGHT if self.prediction == "gefährlich" else GOOD_LIGHT
            pygame.draw.rect(
                self.canvas,
                result_fill,
                result,
                border_radius=12,
            )
            pygame.draw.rect(
                self.canvas,
                result_color,
                result,
                width=2,
                border_radius=12,
            )
            self.centered(
                self.tiny,
                "Mehrheit des Waldes:",
                (result.centerx, result.centery - 14),
                MUTED,
            )
            self.centered(
                self.bold,
                self.prediction,
                (result.centerx, result.centery + 12),
                result_color,
            )

        # Auswertung
        self.centered(
            self.big,
            "Auswertung",
            (right.centerx, right.top + 35),
        )
        score_box = pygame.Rect(
            right.left + 28,
            right.top + 90,
            right.width - 56,
            80,
        )
        pygame.draw.rect(
            self.canvas,
            PANEL_ALT,
            score_box,
            border_radius=12,
        )
        answered = len(self.answered)
        self.centered(
            self.small,
            "Bisher richtig",
            (score_box.centerx, score_box.centery - 18),
            MUTED,
        )
        self.centered(
            self.huge,
            f"{self.score}/{answered}" if answered else "–",
            (score_box.centerx, score_box.centery + 16),
        )

        if self.prediction is not None:
            correct = self.prediction == m.label
            self.centered(
                self.big,
                "Richtig!" if correct else "Nicht ganz!",
                (right.centerx, right.top + 225),
                GOOD if correct else BAD,
            )
            self.centered(
                self.small,
                f"Richtige Klasse: {m.label}",
                (right.centerx, right.top + 263),
            )
            self.wrap(
                self.small,
                "Jeder Baum wurde von dir gebaut. Der Random Forest kombiniert "
                "ihre unterschiedlichen Entscheidungen per Mehrheitsabstimmung.",
                pygame.Rect(
                    right.left + 28,
                    right.top + 300,
                    right.width - 56,
                    110,
                ),
            )
        else:
            self.wrap(
                self.small,
                "Die echte Klasse bleibt versteckt, bis alle Bäume abgestimmt haben.",
                pygame.Rect(
                    right.left + 32,
                    right.top + 220,
                    right.width - 64,
                    90,
                ),
            )

        self.text(
            self.tiny,
            f"Wald: {self.num_trees} Bäume · {self.max_features} Merkmale/Split",
            (right.left + 28, right.top + 440),
            MUTED,
        )

    # --------------------------------------------------------

    # BUTTONS ERZEUGEN

    # --------------------------------------------------------



    def build_buttons(self) -> None:
        self.buttons = []

        if self.phase == 1:
            self.buttons.append(
                Button(
                    pygame.Rect(
                        WIDTH - 270,
                        HEIGHT - 72,
                        235,
                        46,
                    ),
                    "Weiter: Random Forest",
                    "phase2",
                )
            )

        elif self.phase == 2:
            control_x = 1130

            # Anzahl der Baeume
            self.buttons.append(
                Button(
                    pygame.Rect(control_x, 181, 70, 40),
                    "− 1",
                    "trees_delta",
                    "-1",
                    enabled=self.num_trees > 2,
                )
            )
            self.buttons.append(
                Button(
                    pygame.Rect(control_x + 195, 181, 70, 40),
                    "+ 1",
                    "trees_delta",
                    "1",
                )
            )

            # Merkmale pro Split / maximales Blatt-Limit
            for i in range(1, len(FEATURES) + 1):
                self.buttons.append(
                    Button(
                        pygame.Rect(
                            control_x + (i - 1) * 53,
                            312,
                            47,
                            38,
                        ),
                        str(i),
                        "features",
                        str(i),
                        enabled=i >= self.max_tree_leaf_count(),
                        active=self.max_features == i,
                    )
                )

            # Zwischen den selbst gebauten Baeumen wechseln
            self.buttons.append(
                Button(
                    pygame.Rect(control_x, 382, 82, 40),
                    "←",
                    "tree_prev",
                    enabled=self.active_tree_index > 0,
                )
            )
            self.buttons.append(
                Button(
                    pygame.Rect(control_x + 183, 382, 82, 40),
                    "→",
                    "tree_next",
                    enabled=self.active_tree_index < self.num_trees - 1,
                )
            )

            self.buttons.append(
                Button(
                    pygame.Rect(control_x, 798, 125, 34),
                    "Baum leeren",
                    "reset_tree",
                )
            )
            self.buttons.append(
                Button(
                    pygame.Rect(control_x + 140, 798, 125, 34),
                    "Wald leeren",
                    "reset_forest",
                )
            )
            self.buttons.append(
                Button(
                    pygame.Rect(control_x, 848, 265, 46),
                    "Weiter: Monster testen",
                    "phase3",
                    enabled=self.all_trees_started(),
                )
            )

            menu = self.context_menu_rect()
            if (
                menu is not None
                and self.context_leaf_path is not None
            ):
                candidates = self.candidate_features(
                    self.context_leaf_path
                )
                for i, feature in enumerate(candidates):
                    self.buttons.append(
                        Button(
                            pygame.Rect(
                                menu.left + 10,
                                menu.top + 46 + i * 38,
                                menu.width - 20,
                                32,
                            ),
                            f"+ {FEATURE_LABELS[feature]}",
                            "split_leaf",
                            feature,
                            enabled=self.can_split_active_tree(),
                        )
                    )

                self.buttons.append(
                    Button(
                        pygame.Rect(
                            menu.left + 10,
                            menu.bottom - 70,
                            menu.width - 20,
                            27,
                        ),
                        "Blatt loeschen",
                        "delete_leaf",
                        enabled=bool(self.context_leaf_path),
                    )
                )

                self.buttons.append(
                    Button(
                        pygame.Rect(
                            menu.left + 10,
                            menu.bottom - 36,
                            menu.width - 20,
                            27,
                        ),
                        "Abbrechen",
                        "close_context",
                    )
                )

        else:
            if self.test_finished:
                self.buttons.append(
                    Button(
                        pygame.Rect(190, 630, 240, 52),
                        "Wald verbessern",
                        "improve_forest",
                    )
                )
                self.buttons.append(
                    Button(
                        pygame.Rect(470, 630, 240, 52),
                        "Nochmal testen",
                        "retry_test",
                        active=True,
                    )
                )
                self.buttons.append(
                    Button(
                        pygame.Rect(750, 630, 240, 52),
                        "Neu starten",
                        "restart_game",
                    )
                )
            else:
                self.buttons.append(
                    Button(
                        pygame.Rect(850, 560, 285, 50),
                        "Wald entscheiden",
                        "predict",
                        enabled=self.prediction is None,
                    )
                )

                last_monster = (
                    self.test_index == len(TEST_DATA) - 1
                )
                self.buttons.append(
                    Button(
                        pygame.Rect(850, 620, 285, 50),
                        "Test abschließen"
                        if last_monster
                        else "Nächstes Monster",
                        "finish_test"
                        if last_monster
                        else "next",
                        enabled=self.prediction is not None,
                    )
                )
                self.buttons.append(
                    Button(
                        pygame.Rect(850, 680, 285, 42),
                        "Zurück zum Wald",
                        "phase2",
                    )
                )

    # --------------------------------------------------------

    # BUTTON AKTION

    # --------------------------------------------------------



    def handle_button(
        self,
        b: Button,
    ) -> None:
        if not b.enabled:
            return

        if b.action == "phase2":
            self.phase = 2
            self.test_finished = False
            return

        if b.action == "trees_delta" and b.value is not None:
            self.resize_forest(
                self.num_trees + int(b.value)
            )
            return

        if b.action == "features" and b.value is not None:
            requested = max(
                1,
                min(len(FEATURES), int(b.value)),
            )
            # Ein bestehender Baum darf durch das Verkleinern des Limits nicht
            # ploetzlich mehr Blaetter als erlaubt besitzen.
            if requested < self.max_tree_leaf_count():
                return
            self.max_features = requested
            self.context_leaf_path = None
            self.context_menu_pos = None
            return

        if b.action == "tree_prev":
            self.activate_tree(self.active_tree_index - 1)
            return

        if b.action == "tree_next":
            self.activate_tree(self.active_tree_index + 1)
            return

        if b.action == "phase3":
            if not self.all_trees_started():
                return
            self.save_active_tree_scroll()
            self.phase = 3
            self.context_leaf_path = None
            self.context_menu_pos = None
            self.reset_test()
            return

        if b.action == "improve_forest":
            self.phase = 2
            self.test_finished = False
            return

        if b.action == "retry_test":
            self.phase = 3
            self.reset_test()
            return

        if b.action == "restart_game":
            self.reset_game()
            return

        if (
            b.action == "split_leaf"
            and b.value
            and self.context_leaf_path is not None
        ):
            if self.can_split_active_tree():
                self.tree.split_leaf(
                    self.context_leaf_path,
                    b.value,
                )
            self.context_leaf_path = None
            self.context_menu_pos = None
            return

        if (
            b.action == "delete_leaf"
            and self.context_leaf_path is not None
        ):
            self.tree.delete_leaf(self.context_leaf_path)
            self.context_leaf_path = None
            self.context_menu_pos = None
            return

        if b.action == "close_context":
            self.context_leaf_path = None
            self.context_menu_pos = None
            return

        if b.action == "reset_tree":
            self.reset_current_tree()
            return

        if b.action == "reset_forest":
            self.reset_forest()
            return

        if (
            b.action == "predict"
            and self.prediction is None
        ):
            monster = TEST_DATA[self.test_index]
            (
                self.vote_dangerous,
                self.vote_friendly,
                self.individual_votes,
                self.individual_paths,
            ) = self.forest_votes(monster)
            self.prediction = (
                "gefährlich"
                if self.vote_dangerous > self.vote_friendly
                else "freundlich"
            )

            if self.test_index not in self.answered:
                self.score += int(
                    self.prediction == monster.label
                )
                self.answered.add(self.test_index)
            return

        if (
            b.action == "next"
            and self.prediction is not None
            and self.test_index < len(TEST_DATA) - 1
        ):
            self.test_index += 1
            self.prediction = None
            self.vote_dangerous = 0
            self.vote_friendly = 0
            self.individual_votes = []
            self.individual_paths = []
            return

        if (
            b.action == "finish_test"
            and self.prediction is not None
            and self.test_index == len(TEST_DATA) - 1
        ):
            self.test_finished = True
            return

    # --------------------------------------------------------

    # MAUSKLICK

    # --------------------------------------------------------



    def click(
        self,
        pos: Tuple[int, int],
    ) -> None:
        self.build_buttons()

        for b in reversed(self.buttons):
            if b.rect.collidepoint(pos):
                self.handle_button(b)
                return

        if self.context_leaf_path is not None:
            self.context_leaf_path = None
            self.context_menu_pos = None

        if self.phase == 2:
            for key, rect in self.leaf_hitboxes.items():
                if rect.collidepoint(pos):
                    self.cycle_leaf(key)
                    return

        if self.phase == 1:
            for i in range(min(12, len(TRAINING))):
                if self.card_rect(i).collidepoint(pos):
                    self.selected_training = i
                    return

    def right_click(
        self,
        pos: Tuple[int, int],
    ) -> None:
        if self.phase != 2:
            return


        for key, rect in self.leaf_hitboxes.items():
            if rect.collidepoint(pos):
                self.context_leaf_path = key
                self.context_menu_pos = pos
                return

        self.context_leaf_path = None
        self.context_menu_pos = None

    def screen_to_canvas(
        self,
        pos: Tuple[int, int],
    ) -> Tuple[int, int]:
        return (
            pos[0] - self.canvas_offset[0],
            pos[1] - self.canvas_offset[1],
        )

    def draw_tree_scrollbars(
        self,
        view: pygame.Rect,
    ) -> None:
        """Zeigt ziehbare Scrollbalken direkt am aktiven Baum."""
        max_x, max_y = self.tree_scroll_limits

        self.tree_h_scroll_track = pygame.Rect(
            view.left,
            view.bottom + 3,
            view.width,
            10,
        )
        self.tree_v_scroll_track = pygame.Rect(
            view.right + 3,
            view.top,
            10,
            view.height,
        )

        pygame.draw.rect(
            self.canvas,
            (220, 226, 234),
            self.tree_h_scroll_track,
            border_radius=5,
        )
        pygame.draw.rect(
            self.canvas,
            (220, 226, 234),
            self.tree_v_scroll_track,
            border_radius=5,
        )

        # Die Thumb-Groesse zeigt, wie viel vom virtuellen aktiven Baum sichtbar ist.
        virtual_w = view.width + max_x
        virtual_h = view.height + max_y

        h_w = self.tree_h_scroll_track.width
        if virtual_w > 0:
            h_w = max(
                34,
                int(
                    self.tree_h_scroll_track.width
                    * view.width
                    / virtual_w
                ),
            )
        h_w = min(h_w, self.tree_h_scroll_track.width)

        v_h = self.tree_v_scroll_track.height
        if virtual_h > 0:
            v_h = max(
                34,
                int(
                    self.tree_v_scroll_track.height
                    * view.height
                    / virtual_h
                ),
            )
        v_h = min(v_h, self.tree_v_scroll_track.height)

        h_range = self.tree_h_scroll_track.width - h_w
        v_range = self.tree_v_scroll_track.height - v_h

        h_x = self.tree_h_scroll_track.left
        if max_x > 0 and h_range > 0:
            h_x += int(self.tree_scroll_x / max_x * h_range)

        v_y = self.tree_v_scroll_track.top
        if max_y > 0 and v_range > 0:
            v_y += int(self.tree_scroll_y / max_y * v_range)

        self.tree_h_scroll_thumb = pygame.Rect(
            h_x,
            self.tree_h_scroll_track.top,
            h_w,
            self.tree_h_scroll_track.height,
        )
        self.tree_v_scroll_thumb = pygame.Rect(
            self.tree_v_scroll_track.left,
            v_y,
            self.tree_v_scroll_track.width,
            v_h,
        )

        h_color = ACCENT if max_x > 0 else BORDER
        v_color = ACCENT if max_y > 0 else BORDER
        pygame.draw.rect(
            self.canvas,
            h_color,
            self.tree_h_scroll_thumb,
            border_radius=5,
        )
        pygame.draw.rect(
            self.canvas,
            v_color,
            self.tree_v_scroll_thumb,
            border_radius=5,
        )

    def start_tree_scroll_drag(
        self,
        pos: Tuple[int, int],
    ) -> bool:
        """Startet Ziehen oder Springen innerhalb eines Scrollbalkens."""
        if self.phase != 2:
            return False

        max_x, max_y = self.tree_scroll_limits

        if max_x > 0 and self.tree_h_scroll_thumb.collidepoint(pos):
            self.tree_scroll_drag = "x"
            self.tree_scroll_drag_offset = pos[0] - self.tree_h_scroll_thumb.left
            return True

        if max_y > 0 and self.tree_v_scroll_thumb.collidepoint(pos):
            self.tree_scroll_drag = "y"
            self.tree_scroll_drag_offset = pos[1] - self.tree_v_scroll_thumb.top
            return True

        if max_x > 0 and self.tree_h_scroll_track.collidepoint(pos):
            thumb_w = self.tree_h_scroll_thumb.width
            travel = self.tree_h_scroll_track.width - thumb_w
            if travel > 0:
                thumb_left = max(
                    self.tree_h_scroll_track.left,
                    min(
                        pos[0] - thumb_w // 2,
                        self.tree_h_scroll_track.right - thumb_w,
                    ),
                )
                ratio = (
                    thumb_left - self.tree_h_scroll_track.left
                ) / travel
                self.tree_scroll_x = int(ratio * max_x)
            return True

        if max_y > 0 and self.tree_v_scroll_track.collidepoint(pos):
            thumb_h = self.tree_v_scroll_thumb.height
            travel = self.tree_v_scroll_track.height - thumb_h
            if travel > 0:
                thumb_top = max(
                    self.tree_v_scroll_track.top,
                    min(
                        pos[1] - thumb_h // 2,
                        self.tree_v_scroll_track.bottom - thumb_h,
                    ),
                )
                ratio = (
                    thumb_top - self.tree_v_scroll_track.top
                ) / travel
                self.tree_scroll_y = int(ratio * max_y)
            return True

        return False

    def drag_tree_scrollbar(
        self,
        pos: Tuple[int, int],
    ) -> None:
        if self.phase != 2 or self.tree_scroll_drag is None:
            return

        max_x, max_y = self.tree_scroll_limits

        if self.tree_scroll_drag == "x" and max_x > 0:
            thumb_w = self.tree_h_scroll_thumb.width
            travel = self.tree_h_scroll_track.width - thumb_w
            if travel > 0:
                thumb_left = pos[0] - self.tree_scroll_drag_offset
                thumb_left = max(
                    self.tree_h_scroll_track.left,
                    min(
                        thumb_left,
                        self.tree_h_scroll_track.right - thumb_w,
                    ),
                )
                ratio = (
                    thumb_left - self.tree_h_scroll_track.left
                ) / travel
                self.tree_scroll_x = int(ratio * max_x)

        elif self.tree_scroll_drag == "y" and max_y > 0:
            thumb_h = self.tree_v_scroll_thumb.height
            travel = self.tree_v_scroll_track.height - thumb_h
            if travel > 0:
                thumb_top = pos[1] - self.tree_scroll_drag_offset
                thumb_top = max(
                    self.tree_v_scroll_track.top,
                    min(
                        thumb_top,
                        self.tree_v_scroll_track.bottom - thumb_h,
                    ),
                )
                ratio = (
                    thumb_top - self.tree_v_scroll_track.top
                ) / travel
                self.tree_scroll_y = int(ratio * max_y)

    def stop_tree_scroll_drag(self) -> None:
        self.tree_scroll_drag = None
        self.tree_scroll_drag_offset = 0

    def scroll_tree(
        self,
        wheel_x: int,
        wheel_y: int,
        mods: int,
    ) -> None:
        if self.phase != 2:
            return

        mouse_pos = self.screen_to_canvas(
            pygame.mouse.get_pos()
        )
        if not self.tree_view_rect.collidepoint(mouse_pos):
            return

        max_x, max_y = self.tree_scroll_limits
        step = 70

        horizontal = bool(mods & pygame.KMOD_SHIFT)
        if horizontal:
            self.tree_scroll_x -= wheel_y * step
        else:
            self.tree_scroll_y -= wheel_y * step
            self.tree_scroll_x -= wheel_x * step

        self.tree_scroll_x = max(
            0,
            min(self.tree_scroll_x, max_x),
        )
        self.tree_scroll_y = max(
            0,
            min(self.tree_scroll_y, max_y),
        )


    # --------------------------------------------------------

    # ZEICHNEN

    # --------------------------------------------------------



    def draw(self) -> None:

        target_size = (
            (TREE_WIDTH, TREE_HEIGHT)
            if self.phase == 2
            else (WIDTH, HEIGHT)
        )
        if self.canvas.get_size() != target_size:
            self.canvas = pygame.Surface(target_size).convert()

        self.canvas_offset = (
            (WINDOW_WIDTH - target_size[0]) // 2,
            (WINDOW_HEIGHT - target_size[1]) // 2,
        )

        self.canvas.fill(BG)

        self.header()



        if self.phase == 1:

            self.phase1()



        elif self.phase == 2:

            self.phase2()



        else:

            self.phase3()



        self.build_buttons()



        for b in self.buttons:

            b.draw(

                self.canvas,

                self.small,

                self.tiny,

            )



        # Keine Skalierung: Training/Test werden zentriert; Phase 2 nutzt
        # die volle Fensterflaeche fuer die Baum-Arbeitsflaeche.
        self.display.fill((225, 230, 238))

        self.display.blit(

            self.canvas,

            self.canvas_offset,

        )



        pygame.display.flip()



    # --------------------------------------------------------

    # HAUPTSCHLEIFE

    # --------------------------------------------------------



    def loop(self) -> None:

        while True:

            for event in pygame.event.get():



                if event.type == pygame.QUIT:

                    pygame.quit()

                    sys.exit()



                if (

                    event.type

                    == pygame.KEYDOWN

                    and event.key

                    == pygame.K_ESCAPE

                ):

                    pygame.quit()

                    sys.exit()



                if (

                    event.type

                    == pygame.MOUSEBUTTONDOWN

                    and event.button == 1

                ):

                    canvas_pos = self.screen_to_canvas(event.pos)
                    if not self.start_tree_scroll_drag(canvas_pos):
                        self.click(canvas_pos)



                if (

                    event.type

                    == pygame.MOUSEBUTTONDOWN

                    and event.button == 3

                ):

                    self.right_click(

                        self.screen_to_canvas(event.pos)

                    )



                if event.type == pygame.MOUSEMOTION:
                    if self.tree_scroll_drag is not None:
                        self.drag_tree_scrollbar(
                            self.screen_to_canvas(event.pos)
                        )

                if (
                    event.type == pygame.MOUSEBUTTONUP
                    and event.button == 1
                ):
                    self.stop_tree_scroll_drag()

                if event.type == pygame.MOUSEWHEEL:

                    self.scroll_tree(

                        event.x,

                        event.y,

                        pygame.key.get_mods(),

                    )



            self.draw()



            self.clock.tick(FPS)





# ------------------------------------------------------------

# START

# ------------------------------------------------------------



if __name__ == "__main__":

    Game().loop()