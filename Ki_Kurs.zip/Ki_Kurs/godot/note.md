# Godot 

### UI
- evtl mit M oder nicht


### Games 
Gedanken machen welches Game ihr wollt,
falls ihr es noch nicht wisst, was bockt, dann probiert mit
python einfach sachen aus.

### TODO 
- Platformen bewegen 
- Münzen sammeln
- Template je SpielTyp anlegen 
