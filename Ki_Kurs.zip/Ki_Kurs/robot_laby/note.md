# Monster Detektiv

## Decision Tree
### Instruktion
- Kinder spielen mit dem Labyrinth und versuchen zu verstehen wie der Roboter sich bewegt.


### Goal 
- Kinder spielen mit Labyrinth rum: erstellen Waende und Boden
- Kinder verstehen den Mechanismus

### Aufwand
- 10 Min.



