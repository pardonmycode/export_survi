# Sumory


### Goal
- Kinder sollen lernen zwischen Erkunden und Nutzen zu unterscheiden