import random
import pygame

# ------------------------------------------------------------
# Settings
# ------------------------------------------------------------
WIDTH, HEIGHT = 1100, 820
FPS = 60

ROWS = 3
COLS = 7
NUM_CARDS = ROWS * COLS

TOTAL_ROUNDS = 5
TURNS_PER_PLAYER = 10
TOTAL_TURNS_PER_ROUND = TURNS_PER_PLAYER * 2

MIN_VALUE = -20
MAX_VALUE = 25
UNIQUE_RANDOM_VALUES = True

# Colors
BG = (245, 246, 250)
PANEL = (255, 255, 255)
TEXT = (35, 39, 47)
MUTED = (100, 106, 117)
CARD_HIDDEN = (210, 214, 223)
CARD_HIDDEN_HOVER = (190, 196, 208)
CARD_REVEALED = (255, 255, 255)
CARD_BORDER = (150, 157, 171)
POSITIVE = (55, 150, 90)
NEGATIVE = (195, 70, 70)
ZERO = (90, 95, 110)
PLAYER_1 = (70, 110, 220)
PLAYER_2 = (220, 120, 70)
ACCENT = (78, 115, 223)
ACCENT_HOVER = (63, 96, 195)
SELECTED = (255, 200, 80)

pygame.init()
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Sumory - 2 Spieler")
clock = pygame.time.Clock()

FONT_TITLE = pygame.font.SysFont("arial", 38, bold=True)
FONT_BIG = pygame.font.SysFont("arial", 30, bold=True)
FONT_CARD = pygame.font.SysFont("arial", 30, bold=True)
FONT_NORMAL = pygame.font.SysFont("arial", 21)
FONT_SMALL = pygame.font.SysFont("arial", 17)
FONT_TINY = pygame.font.SysFont("arial", 15)


class Card:
    def __init__(self, rect, value):
        self.rect = pygame.Rect(rect)
        self.value = value
        self.revealed = False
        self.last_selected = False
        self.last_player = None

    def draw(self, surface, mouse_pos, reveal_all=False):
        hovered = self.rect.collidepoint(mouse_pos)

        if self.revealed or reveal_all:
            fill = CARD_REVEALED
        else:
            fill = CARD_HIDDEN_HOVER if hovered else CARD_HIDDEN

        pygame.draw.rect(surface, fill, self.rect, border_radius=14)

        if self.last_selected:
            border_color = PLAYER_1 if self.last_player == 0 else PLAYER_2
            border_width = 5
        else:
            border_color = CARD_BORDER
            border_width = 2

        pygame.draw.rect(surface, border_color, self.rect, border_width, border_radius=14)

        if self.revealed or reveal_all:
            if self.value > 0:
                color = POSITIVE
            elif self.value < 0:
                color = NEGATIVE
            else:
                color = ZERO

            text = FONT_CARD.render(str(self.value), True, color)
            surface.blit(text, text.get_rect(center=self.rect.center))
        else:
            text = FONT_BIG.render("?", True, MUTED)
            surface.blit(text, text.get_rect(center=self.rect.center))


class Button:
    def __init__(self, rect, text):
        self.rect = pygame.Rect(rect)
        self.text = text
        self.enabled = True

    def draw(self, surface, mouse_pos):
        if not self.enabled:
            color = (175, 180, 190)
        else:
            color = ACCENT_HOVER if self.rect.collidepoint(mouse_pos) else ACCENT

        pygame.draw.rect(surface, color, self.rect, border_radius=12)
        text = FONT_NORMAL.render(self.text, True, (255, 255, 255))
        surface.blit(text, text.get_rect(center=self.rect.center))

    def clicked(self, pos):
        return self.enabled and self.rect.collidepoint(pos)


def generate_values():
    possible = list(range(MIN_VALUE, MAX_VALUE + 1))

    if UNIQUE_RANDOM_VALUES and len(possible) >= NUM_CARDS:
        return random.sample(possible, NUM_CARDS)

    return [random.randint(MIN_VALUE, MAX_VALUE) for _ in range(NUM_CARDS)]


def make_cards():
    values = generate_values()

    card_w = 120
    card_h = 125
    gap_x = 20
    gap_y = 22

    grid_width = COLS * card_w + (COLS - 1) * gap_x
    start_x = (WIDTH - grid_width) // 2
    start_y = 270

    cards = []
    i = 0
    for row in range(ROWS):
        for col in range(COLS):
            x = start_x + col * (card_w + gap_x)
            y = start_y + row * (card_h + gap_y)
            cards.append(Card((x, y, card_w, card_h), values[i]))
            i += 1

    return cards


def draw_text(surface, text, font, color, x, y, anchor="topleft"):
    img = font.render(text, True, color)
    rect = img.get_rect()
    setattr(rect, anchor, (x, y))
    surface.blit(img, rect)


def start_match():
    state = {
        "round": 1,
        "current_player": 0,
        "round_scores": [0, 0],
        "turns": [0, 0],
        "total_scores": [0, 0],
        "round_wins": [0, 0],
        "last_value": None,
        "last_player": None,
        "round_over": False,
        "match_over": False,
        "round_result": "",
        "match_result": "",
    }
    return make_cards(), state


def start_next_round(state):
    state["round"] += 1
    state["current_player"] = 0 if state["round"] % 2 == 1 else 1
    state["round_scores"] = [0, 0]
    state["turns"] = [0, 0]
    state["last_value"] = None
    state["last_player"] = None
    state["round_over"] = False
    state["round_result"] = ""
    return make_cards()


def finish_round(state):
    state["round_over"] = True
    p1 = state["round_scores"][0]
    p2 = state["round_scores"][1]

    if p1 > p2:
        state["round_wins"][0] += 1
        state["round_result"] = f"Spieler 1 gewinnt Runde {state['round']} mit {p1} zu {p2}."
    elif p2 > p1:
        state["round_wins"][1] += 1
        state["round_result"] = f"Spieler 2 gewinnt Runde {state['round']} mit {p2} zu {p1}."
    else:
        state["round_result"] = f"Runde {state['round']} endet unentschieden: {p1} zu {p2}."

    if state["round"] >= TOTAL_ROUNDS:
        finish_match(state)


def finish_match(state):
    state["match_over"] = True

    wins_1, wins_2 = state["round_wins"]
    total_1, total_2 = state["total_scores"]

    if wins_1 > wins_2:
        state["match_result"] = f"Spieler 1 gewinnt das Match mit {wins_1}:{wins_2} Runden."
    elif wins_2 > wins_1:
        state["match_result"] = f"Spieler 2 gewinnt das Match mit {wins_2}:{wins_1} Runden."
    elif total_1 > total_2:
        state["match_result"] = (
            f"Runden gleich - Spieler 1 gewinnt nach Gesamtpunkten: {total_1} zu {total_2}."
        )
    elif total_2 > total_1:
        state["match_result"] = (
            f"Runden gleich - Spieler 2 gewinnt nach Gesamtpunkten: {total_2} zu {total_1}."
        )
    else:
        state["match_result"] = "Das Match endet komplett unentschieden."


def select_card(card, cards, state):
    player = state["current_player"]

    for c in cards:
        c.last_selected = False

    card.revealed = True
    card.last_selected = True
    card.last_player = player

    state["round_scores"][player] += card.value
    state["total_scores"][player] += card.value
    state["turns"][player] += 1
    state["last_value"] = card.value
    state["last_player"] = player

    if sum(state["turns"]) >= TOTAL_TURNS_PER_ROUND:
        finish_round(state)
        return

    # Strict alternation after every click.
    other_player = 1 - player

    if state["turns"][other_player] < TURNS_PER_PLAYER:
        state["current_player"] = other_player
    elif state["turns"][player] < TURNS_PER_PLAYER:
        state["current_player"] = player


cards, state = start_match()
new_match_button = Button((WIDTH - 205, 32, 165, 50), "Neues Match")
next_round_button = Button((WIDTH - 235, 748, 195, 48), "Naechste Runde")

running = True
while running:
    clock.tick(FPS)
    mouse_pos = pygame.mouse.get_pos()

    next_round_button.enabled = state["round_over"] and not state["match_over"]

    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

        elif event.type == pygame.KEYDOWN:
            if event.key == pygame.K_ESCAPE:
                running = False
            elif event.key == pygame.K_r:
                cards, state = start_match()
            elif event.key == pygame.K_SPACE and next_round_button.enabled:
                cards = start_next_round(state)

        elif event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
            if new_match_button.clicked(event.pos):
                cards, state = start_match()
                continue

            if next_round_button.clicked(event.pos):
                cards = start_next_round(state)
                continue

            if not state["round_over"] and not state["match_over"]:
                player = state["current_player"]

                if state["turns"][player] >= TURNS_PER_PLAYER:
                    state["current_player"] = 1 - player
                    continue

                for card in cards:
                    if card.rect.collidepoint(event.pos):
                        select_card(card, cards, state)
                        break

    # --------------------------------------------------------
    # Draw
    # --------------------------------------------------------
    screen.fill(BG)

    pygame.draw.rect(screen, PANEL, (25, 20, WIDTH - 50, 225), border_radius=18)
    draw_text(screen, "SUMORY - 2 SPIELER", FONT_TITLE, TEXT, 48, 37)
    draw_text(
        screen,
        f"Runde {state['round']}/{TOTAL_ROUNDS} - nach jedem Kartenklick wechselt der Spieler.",
        FONT_NORMAL,
        MUTED,
        50,
        88,
    )

    # Player panels
    p1_rect = pygame.Rect(45, 125, 315, 95)
    p2_rect = pygame.Rect(385, 125, 315, 95)

    p1_border = PLAYER_1 if state["current_player"] == 0 and not state["round_over"] else CARD_BORDER
    p2_border = PLAYER_2 if state["current_player"] == 1 and not state["round_over"] else CARD_BORDER

    pygame.draw.rect(screen, PANEL, p1_rect, border_radius=14)
    pygame.draw.rect(screen, p1_border, p1_rect, 4, border_radius=14)
    pygame.draw.rect(screen, PANEL, p2_rect, border_radius=14)
    pygame.draw.rect(screen, p2_border, p2_rect, 4, border_radius=14)

    draw_text(screen, "Spieler 1", FONT_NORMAL, PLAYER_1, 62, 138)
    draw_text(screen, f"Punkte: {state['round_scores'][0]}", FONT_BIG, TEXT, 62, 167)
    draw_text(
        screen,
        f"Zuege: {state['turns'][0]}/{TURNS_PER_PLAYER}   |   Rundensiege: {state['round_wins'][0]}",
        FONT_TINY,
        MUTED,
        62,
        202,
    )

    draw_text(screen, "Spieler 2", FONT_NORMAL, PLAYER_2, 402, 138)
    draw_text(screen, f"Punkte: {state['round_scores'][1]}", FONT_BIG, TEXT, 402, 167)
    draw_text(
        screen,
        f"Zuege: {state['turns'][1]}/{TURNS_PER_PLAYER}   |   Rundensiege: {state['round_wins'][1]}",
        FONT_TINY,
        MUTED,
        402,
        202,
    )

    # Match info
    draw_text(screen, "Gesamtpunkte", FONT_SMALL, MUTED, 735, 128)
    draw_text(screen, f"S1: {state['total_scores'][0]}", FONT_NORMAL, PLAYER_1, 735, 154)
    draw_text(screen, f"S2: {state['total_scores'][1]}", FONT_NORMAL, PLAYER_2, 735, 184)

    new_match_button.draw(screen, mouse_pos)

    if not state["round_over"]:
        active_color = PLAYER_1 if state["current_player"] == 0 else PLAYER_2
        draw_text(
            screen,
            f"Am Zug: Spieler {state['current_player'] + 1}",
            FONT_NORMAL,
            active_color,
            915,
            137,
            anchor="midtop",
        )

    if state["last_value"] is not None:
        sign = "+" if state["last_value"] > 0 else ""
        value_color = POSITIVE if state["last_value"] > 0 else NEGATIVE if state["last_value"] < 0 else ZERO
        draw_text(
            screen,
            f"Letzter Zug: S{state['last_player'] + 1}  {sign}{state['last_value']}",
            FONT_SMALL,
            value_color,
            915,
            184,
            anchor="midtop",
        )

    # Cards
    for card in cards:
        card.draw(screen, mouse_pos, state["round_over"])

    # Footer
    pygame.draw.rect(screen, PANEL, (25, 727, WIDTH - 50, 73), border_radius=16)

    if state["match_over"]:
        draw_text(screen, state["match_result"], FONT_NORMAL, TEXT, 48, 742)
        draw_text(screen, "Druecke R oder klicke auf 'Neues Match'.", FONT_SMALL, MUTED, 48, 772)
    elif state["round_over"]:
        draw_text(screen, state["round_result"], FONT_NORMAL, TEXT, 48, 742)
        draw_text(screen, "Alle Karten sind sichtbar. Leertaste oder Button fuer die naechste Runde.", FONT_SMALL, MUTED, 48, 772)
        next_round_button.draw(screen, mouse_pos)
    else:
        draw_text(
            screen,
            "Neue Karte aufdecken oder bekannte Karte erneut nutzen - jeder Klick ist genau ein Zug.",
            FONT_SMALL,
            MUTED,
            WIDTH // 2,
            750,
            anchor="midtop",
        )
        draw_text(
            screen,
            f"In jeder Runde hat jeder Spieler {TURNS_PER_PLAYER} Zuege.",
            FONT_TINY,
            MUTED,
            WIDTH // 2,
            778,
            anchor="midtop",
        )

    pygame.display.flip()

pygame.quit()
