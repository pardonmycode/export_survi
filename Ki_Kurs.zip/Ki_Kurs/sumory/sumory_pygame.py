import random
import pygame

# ------------------------------------------------------------
# Einstellungen
# ------------------------------------------------------------
WIDTH, HEIGHT = 1100, 760
FPS = 60

ROWS = 3
COLS = 7
NUM_CARDS = ROWS * COLS
MAX_TURNS = 10

# Zufallszahlen fuer jede neue Runde
MIN_VALUE = -20
MAX_VALUE = 25

# Wenn True: Alle 21 Karten bekommen unterschiedliche Zufallszahlen.
# Falls der Bereich zu klein ist, wird automatisch mit Wiederholungen gezogen.
UNIQUE_RANDOM_VALUES = True

# Farben
BG = (245, 246, 250)
PANEL = (255, 255, 255)
TEXT = (35, 39, 47)
MUTED = (100, 106, 117)
CARD_HIDDEN = (210, 214, 223)
CARD_HIDDEN_HOVER = (190, 196, 208)
CARD_REVEALED = (255, 255, 255)
CARD_BORDER = (150, 157, 171)
POSITIVE = (55, 150, 90)
NEGATIVE = (195, 70, 70)
ZERO = (90, 95, 110)
ACCENT = (78, 115, 223)
ACCENT_HOVER = (63, 96, 195)
SELECTED = (255, 200, 80)

pygame.init()
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Sumory - Pygame")
clock = pygame.time.Clock()

FONT_TITLE = pygame.font.SysFont("arial", 42, bold=True)
FONT_BIG = pygame.font.SysFont("arial", 34, bold=True)
FONT_CARD = pygame.font.SysFont("arial", 30, bold=True)
FONT_NORMAL = pygame.font.SysFont("arial", 22)
FONT_SMALL = pygame.font.SysFont("arial", 17)


class Card:
    def __init__(self, rect, value):
        self.rect = pygame.Rect(rect)
        self.value = value
        self.revealed = False
        self.last_selected = False

    def draw(self, surface, mouse_pos, game_over=False):
        hovered = self.rect.collidepoint(mouse_pos)

        if self.revealed or game_over:
            fill = CARD_REVEALED
        else:
            fill = CARD_HIDDEN_HOVER if hovered else CARD_HIDDEN

        pygame.draw.rect(surface, fill, self.rect, border_radius=14)

        border_color = SELECTED if self.last_selected else CARD_BORDER
        border_width = 4 if self.last_selected else 2
        pygame.draw.rect(surface, border_color, self.rect, border_width, border_radius=14)

        if self.revealed or game_over:
            if self.value > 0:
                color = POSITIVE
            elif self.value < 0:
                color = NEGATIVE
            else:
                color = ZERO

            text = FONT_CARD.render(str(self.value), True, color)
            surface.blit(text, text.get_rect(center=self.rect.center))
        else:
            text = FONT_BIG.render("?", True, MUTED)
            surface.blit(text, text.get_rect(center=self.rect.center))


class Button:
    def __init__(self, rect, text):
        self.rect = pygame.Rect(rect)
        self.text = text

    def draw(self, surface, mouse_pos):
        color = ACCENT_HOVER if self.rect.collidepoint(mouse_pos) else ACCENT
        pygame.draw.rect(surface, color, self.rect, border_radius=12)
        text = FONT_NORMAL.render(self.text, True, (255, 255, 255))
        surface.blit(text, text.get_rect(center=self.rect.center))

    def clicked(self, pos):
        return self.rect.collidepoint(pos)


def generate_values():
    """Erzeugt die zufaelligen Kartenwerte fuer eine neue Runde."""
    possible = list(range(MIN_VALUE, MAX_VALUE + 1))

    if UNIQUE_RANDOM_VALUES and len(possible) >= NUM_CARDS:
        return random.sample(possible, NUM_CARDS)

    return [random.randint(MIN_VALUE, MAX_VALUE) for _ in range(NUM_CARDS)]


def make_cards():
    values = generate_values()

    card_w = 120
    card_h = 125
    gap_x = 20
    gap_y = 22

    grid_width = COLS * card_w + (COLS - 1) * gap_x
    start_x = (WIDTH - grid_width) // 2
    start_y = 235

    cards = []
    i = 0
    for row in range(ROWS):
        for col in range(COLS):
            x = start_x + col * (card_w + gap_x)
            y = start_y + row * (card_h + gap_y)
            cards.append(Card((x, y, card_w, card_h), values[i]))
            i += 1
    return cards


def new_game():
    return make_cards(), 0, 0, None, False


def draw_text(surface, text, font, color, x, y, anchor="topleft"):
    img = font.render(text, True, color)
    rect = img.get_rect()
    setattr(rect, anchor, (x, y))
    surface.blit(img, rect)


cards, score, turns, last_value, game_over = new_game()
new_game_button = Button((WIDTH - 210, 35, 170, 52), "Neues Spiel")

running = True
while running:
    clock.tick(FPS)
    mouse_pos = pygame.mouse.get_pos()

    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

        elif event.type == pygame.KEYDOWN:
            if event.key == pygame.K_ESCAPE:
                running = False
            elif event.key == pygame.K_r:
                cards, score, turns, last_value, game_over = new_game()

        elif event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
            if new_game_button.clicked(event.pos):
                cards, score, turns, last_value, game_over = new_game()
                continue

            if not game_over:
                for card in cards:
                    if card.rect.collidepoint(event.pos):
                        # Auswahlmarkierung zuruecksetzen
                        for c in cards:
                            c.last_selected = False

                        # Verdeckte Karte beim ersten Klick aufdecken
                        card.revealed = True
                        card.last_selected = True

                        # Jeder Klick auf eine Karte ist ein Zug und wird addiert.
                        score += card.value
                        turns += 1
                        last_value = card.value

                        if turns >= MAX_TURNS:
                            game_over = True
                        break

    # --------------------------------------------------------
    # Zeichnen
    # --------------------------------------------------------
    screen.fill(BG)

    # Kopfbereich
    pygame.draw.rect(screen, PANEL, (25, 20, WIDTH - 50, 185), border_radius=18)
    draw_text(screen, "SUMORY", FONT_TITLE, TEXT, 50, 40)
    draw_text(
        screen,
        "Erkunde neue Karten oder nutze bereits gefundene Karten.",
        FONT_NORMAL,
        MUTED,
        52,
        98,
    )
    draw_text(
        screen,
        f"Zufaellige Kartenwerte: {MIN_VALUE} bis {MAX_VALUE}",
        FONT_SMALL,
        MUTED,
        52,
        136,
    )

    # Statusanzeigen
    draw_text(screen, f"Summe: {score}", FONT_BIG, TEXT, 540, 55)
    draw_text(screen, f"Zuege: {turns}/{MAX_TURNS}", FONT_NORMAL, TEXT, 545, 112)

    if last_value is not None:
        sign = "+" if last_value > 0 else ""
        value_color = POSITIVE if last_value > 0 else NEGATIVE if last_value < 0 else ZERO
        draw_text(screen, f"Letzter Wert: {sign}{last_value}", FONT_NORMAL, value_color, 740, 112)

    new_game_button.draw(screen, mouse_pos)

    # Karten
    for card in cards:
        card.draw(screen, mouse_pos, game_over)

    # Fussbereich / Spielende
    footer_y = 695
    if game_over:
        pygame.draw.rect(screen, PANEL, (25, 675, WIDTH - 50, 65), border_radius=16)
        draw_text(screen, f"Fertig! Deine Summe nach {MAX_TURNS} Zuegen: {score}", FONT_NORMAL, TEXT, 50, 697)
        draw_text(screen, "Alle Karten sind jetzt sichtbar. Druecke R oder 'Neues Spiel'.", FONT_SMALL, MUTED, 50, 726)
    else:
        remaining = MAX_TURNS - turns
        draw_text(
            screen,
            f"Noch {remaining} Zug{'e' if remaining != 1 else ''}. Bereits aufgedeckte Karten koennen erneut angeklickt werden.",
            FONT_SMALL,
            MUTED,
            WIDTH // 2,
            footer_y,
            anchor="midtop",
        )

    pygame.display.flip()

pygame.quit()
